<?php
session_start();
include_once 'includes/config.php';
include_once 'includes/functions.php';

// Get school context from slug
$schoolSlug = isset($_GET['school']) ? trim($_GET['school']) : (isset($_SESSION['school_slug']) ? $_SESSION['school_slug'] : '');
if(!empty($schoolSlug)) {
    $schoolData = getSchoolBySlug($schoolSlug);
    if($schoolData) {
        $_SESSION['school_id'] = $schoolData['id'];
        $_SESSION['school_slug'] = $schoolData['school_slug'];
    }
}
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();

$error = '';
$success = false;
$studentData = null;
$results = [];
$pinUsed = '';
$termUsed = '';
$sessionUsed = '';

if(isset($_POST['checkResult'])) {
    $regNumber = mysqli_real_escape_string($con, trim($_POST['reg_number']));
    $pin = mysqli_real_escape_string($con, strtoupper(trim($_POST['checker_pin'])));
    
    if(empty($regNumber) || empty($pin)) {
        $error = 'Please enter both your Registration Number and Checker PIN.';
    } else {
        // 1. Validate student
        $studentQ = mysqli_query($con, "SELECT * FROM register WHERE examNumber = '$regNumber' AND school_id = $schoolId");
        if(mysqli_num_rows($studentQ) == 0) {
            $error = 'Invalid Registration Number. Please check and try again.';
        } else {
            $studentData = mysqli_fetch_assoc($studentQ);
            
            // 2. Validate PIN
            $pinQ = mysqli_query($con, "SELECT * FROM result_checker_pins WHERE pin = '$pin' AND school_id = $schoolId");
            if(mysqli_num_rows($pinQ) == 0) {
                $error = 'Invalid Checker PIN. Please purchase a valid PIN from the school.';
            } else {
                $pinData = mysqli_fetch_assoc($pinQ);
                
                // 3. Check if PIN is bound to another student
                if($pinData['student_id'] !== null && $pinData['student_id'] != $studentData['id']) {
                    $error = 'This PIN has already been used by another student. Please use your own PIN.';
                }
                // 4. Check usage limit
                elseif($pinData['usage_count'] >= $pinData['max_uses']) {
                    $error = 'This PIN has been exhausted (used ' . $pinData['max_uses'] . '/' . $pinData['max_uses'] . ' times). Please purchase a new PIN.';
                }
                else {
                    // PIN is valid — bind to student if not yet bound, increment usage
                    $pinId = $pinData['id'];
                    $studentId = $studentData['id'];
                    $newCount = $pinData['usage_count'] + 1;
                    $newStatus = ($newCount >= $pinData['max_uses']) ? 'used' : 'active';
                    
                    if($pinData['student_id'] === null) {
                        // First use — bind PIN to this student
                        mysqli_query($con, "UPDATE result_checker_pins SET student_id = $studentId, usage_count = $newCount, status = '$newStatus', last_used_at = NOW() WHERE id = $pinId");
                    } else {
                        // Already bound to this student — just increment
                        mysqli_query($con, "UPDATE result_checker_pins SET usage_count = $newCount, status = '$newStatus', last_used_at = NOW() WHERE id = $pinId");
                    }
                    
                    $termUsed = $pinData['term'];
                    $sessionUsed = $pinData['session'];
                    $pinUsed = $pin;
                    
                    // 5. Fetch results for this student
                    $resultsQ = mysqli_query($con, "
                        SELECT tr.*, s.sub_name 
                        FROM term_results tr 
                        LEFT JOIN subject s ON tr.subject_id = s.sub_id 
                        WHERE tr.student_id = $studentId 
                          AND tr.term = '{$termUsed}' 
                          AND tr.session = '{$sessionUsed}' 
                        ORDER BY s.sub_name
                    ");
                    
                    while($r = mysqli_fetch_assoc($resultsQ)) {
                        $results[] = $r;
                    }
                    
                    $success = true;
                    
                    // Calculate aggregate
                    $totalObtained = 0;
                    $totalObtainable = count($results) * 100;
                    foreach($results as $r) $totalObtained += $r['total'];
                    $average = count($results) > 0 ? round($totalObtained / count($results), 1) : 0;
                    
                    // Get position
                    $classId = $studentData['department'];
                    $posQ = mysqli_query($con, "
                        SELECT tr.student_id, AVG(tr.total) as avg_score 
                        FROM term_results tr 
                        WHERE tr.class_id = '$classId' AND tr.term = '$termUsed' AND tr.session = '$sessionUsed'
                        GROUP BY tr.student_id 
                        ORDER BY avg_score DESC
                    ");
                    $position = 1; $posFound = false;
                    while($posRow = mysqli_fetch_assoc($posQ)) {
                        if($posRow['student_id'] == $studentId) { $posFound = true; break; }
                        $position++;
                    }
                    $totalInClass = mysqli_num_rows($posQ);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $school['school_name']; ?> — Check Result</title>
    <link rel="shortcut icon" href="<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="css/nigerian-cbt.css">
    <link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        .checker-page { min-height:100vh; background:linear-gradient(135deg, #f8faf9 0%, #e8f5e9 50%, #fff8e1 100%); display:flex; align-items:center; justify-content:center; padding:20px; }
        .checker-container { width:100%; max-width:560px; }
        .checker-header { text-align:center; margin-bottom:30px; }
        .checker-header img { width:80px; height:80px; object-fit:contain; margin-bottom:12px; }
        .checker-header h1 { font-family:'Outfit',sans-serif; font-size:1.4rem; color:var(--ng-green-dark); margin-bottom:4px; }
        .checker-header p { color:var(--ng-text-light); font-size:0.9rem; }
        .checker-card { background:white; border-radius:var(--ng-radius); padding:32px; box-shadow:0 4px 24px rgba(0,0,0,0.08); }
        .checker-card h2 { font-family:'Outfit',sans-serif; font-size:1.3rem; margin-bottom:6px; color:var(--ng-green-dark); }
        .checker-card .subtitle { color:var(--ng-text-light); font-size:0.85rem; margin-bottom:24px; }
        .pin-input { letter-spacing:3px; font-family:monospace; font-size:1.1rem !important; text-transform:uppercase; text-align:center; }
        .checker-footer { text-align:center; margin-top:20px; }
        .checker-footer a { color:var(--ng-text-light); font-size:0.85rem; }
        
        /* Result display */
        .result-container { width:100%; max-width:900px; }
        .result-header-card { background:linear-gradient(135deg, var(--ng-green), var(--ng-green-dark)); color:white; border-radius:var(--ng-radius); padding:24px 32px; margin-bottom:24px; display:flex; align-items:center; gap:20px; }
        .result-header-card img.logo { width:60px; height:60px; object-fit:contain; background:white; border-radius:12px; padding:6px; }
        .result-header-card .info h2 { font-family:'Outfit',sans-serif; margin:0 0 4px; }
        .result-header-card .info p { margin:0; opacity:0.9; font-size:0.85rem; }
        .student-info-grid { display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px; margin-bottom:24px; }
        .student-info-grid .info-item { background:white; border-radius:var(--ng-radius-sm); padding:14px 18px; box-shadow:0 2px 8px rgba(0,0,0,0.05); }
        .student-info-grid .info-item label { display:block; font-size:0.75rem; color:var(--ng-text-light); text-transform:uppercase; letter-spacing:0.5px; margin-bottom:4px; }
        .student-info-grid .info-item span { font-weight:700; color:var(--ng-green-dark); font-size:0.95rem; }
        .pin-notice { background:#FFF3CD; border-left:4px solid var(--ng-gold); border-radius:var(--ng-radius-sm); padding:12px 16px; margin-bottom:20px; font-size:0.82rem; color:#856404; }
        .summary-cards { display:grid; grid-template-columns:repeat(4, 1fr); gap:12px; margin-top:24px; }
        .summary-card { background:white; border-radius:var(--ng-radius-sm); padding:16px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,0.05); }
        .summary-card .val { font-size:1.6rem; font-weight:800; font-family:'Outfit',sans-serif; }
        .summary-card .lbl { font-size:0.75rem; color:var(--ng-text-light); text-transform:uppercase; margin-top:4px; }
        .summary-card.green .val { color:var(--ng-green); }
        .summary-card.gold .val { color:var(--ng-gold-dark); }
        
        @media(max-width:768px) {
            .student-info-grid { grid-template-columns:1fr 1fr; }
            .summary-cards { grid-template-columns:1fr 1fr; }
            .result-header-card { flex-direction:column; text-align:center; }
        }
        @media print {
            .checker-footer, .ng-btn, .pin-notice { display:none !important; }
            body { background:white; }
        }
    </style>
</head>
<body>

<?php if(!$success): ?>
<!-- CHECKER FORM -->
<div class="checker-page">
    <div class="checker-container">
        <div class="checker-header">
            <img src="<?php echo $school['school_logo']; ?>" alt="Logo">
            <h1><?php echo $school['school_name']; ?></h1>
            <p><?php echo $school['school_motto']; ?></p>
        </div>

        <div class="checker-card">
            <h2>📋 Check Your Result</h2>
            <p class="subtitle">Enter your Registration Number and Checker PIN to view your term result</p>

            <?php if(!empty($error)): ?>
                <div class="ng-alert ng-alert-error" style="margin-bottom:20px;">
                    <i class="fa fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="post">
                <div class="ng-input-group">
                    <label><i class="fa fa-id-card"></i> Registration Number</label>
                    <input type="text" name="reg_number" class="ng-input" placeholder="e.g. STD/2025/001" 
                           value="<?php echo isset($_POST['reg_number']) ? htmlspecialchars($_POST['reg_number']) : ''; ?>" required>
                </div>
                <div class="ng-input-group">
                    <label><i class="fa fa-key"></i> Checker PIN</label>
                    <input type="text" name="checker_pin" class="ng-input pin-input" placeholder="XXXX-XXXX-XXXX" 
                           maxlength="14" required>
                </div>
                <button type="submit" name="checkResult" class="ng-btn ng-btn-green ng-btn-lg ng-btn-block">
                    <i class="fa fa-search"></i> CHECK RESULT
                </button>
            </form>
        </div>

        <div class="checker-footer">
            <a href="index.php"><i class="fa fa-arrow-left"></i> Back to CBT Login</a>
            &nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="admin/"><i class="fa fa-lock"></i> Admin Portal</a>
        </div>
    </div>
</div>

<?php else: ?>
<!-- RESULT DISPLAY -->
<div class="checker-page" style="align-items:flex-start; padding-top:30px;">
    <div class="result-container">
        
        <!-- School Header -->
        <div class="result-header-card">
            <img src="<?php echo $school['school_logo']; ?>" alt="Logo" class="logo">
            <div class="info">
                <h2><?php echo $school['school_name']; ?></h2>
                <p><?php echo $school['school_address']; ?></p>
                <p style="margin-top:4px;"><strong><?php echo $termUsed; ?> — <?php echo $sessionUsed; ?></strong> Term Result</p>
            </div>
        </div>

        <!-- PIN Notice -->
        <div class="pin-notice">
            <i class="fa fa-info-circle"></i>
            <strong>PIN:</strong> <?php echo $pinUsed; ?> — 
            Usage: <?php echo $pinData['usage_count'] + 1; ?>/<?php echo $pinData['max_uses']; ?> 
            (<?php echo $pinData['max_uses'] - $pinData['usage_count'] - 1; ?> checks remaining)
        </div>

        <!-- Student Info -->
        <div class="student-info-grid">
            <div class="info-item">
                <label>Student Name</label>
                <span><?php echo $studentData['surname'] . ' ' . $studentData['otherNames']; ?></span>
            </div>
            <div class="info-item">
                <label>Reg. Number</label>
                <span><?php echo $studentData['examNumber']; ?></span>
            </div>
            <div class="info-item">
                <label>Class</label>
                <span><?php echo getClassName($studentData['department']); ?></span>
            </div>
        </div>

        <!-- Results Table -->
        <div class="ng-card">
            <div class="ng-card-header"><h3><i class="fa fa-table"></i> Subject Scores</h3></div>
            <div class="ng-card-body" style="padding:0;">
                <table class="ng-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Subject</th>
                            <th>CA1 (20)</th>
                            <th>CA2 (20)</th>
                            <th>Exam (60)</th>
                            <th>Total (100)</th>
                            <th>Grade</th>
                            <th>Remark</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($results) > 0): $sn=0; foreach($results as $r): $sn++; ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td style="font-weight:600;"><?php echo $r['sub_name']; ?></td>
                            <td><?php echo $r['ca1']; ?></td>
                            <td><?php echo $r['ca2']; ?></td>
                            <td><?php echo $r['exam_score']; ?></td>
                            <td style="font-weight:800;"><?php echo $r['total']; ?></td>
                            <td>
                                <span class="ng-badge <?php echo $r['total'] >= 50 ? 'ng-badge-green' : 'ng-badge-red'; ?>">
                                    <?php echo $r['grade']; ?>
                                </span>
                            </td>
                            <td style="font-size:0.82rem;"><?php echo $r['remark']; ?></td>
                        </tr>
                        <?php endforeach; else: ?>
                        <tr><td colspan="8" style="text-align:center; padding:30px; color:var(--ng-text-light);">No results found for this term/session. Please check with your school.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Summary -->
        <?php if(count($results) > 0): ?>
        <div class="summary-cards">
            <div class="summary-card green">
                <div class="val"><?php echo $totalObtained; ?>/<?php echo $totalObtainable; ?></div>
                <div class="lbl">Total Score</div>
            </div>
            <div class="summary-card gold">
                <div class="val"><?php echo $average; ?>%</div>
                <div class="lbl">Average</div>
            </div>
            <div class="summary-card green">
                <div class="val"><?php echo addOrdinalSuffix($position); ?></div>
                <div class="lbl">Position out of <?php echo $totalInClass; ?></div>
            </div>
            <div class="summary-card">
                <div class="val"><?php echo count($results); ?></div>
                <div class="lbl">Subjects</div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Actions -->
        <div style="text-align:center; margin-top:24px; display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
            <button onclick="window.print()" class="ng-btn ng-btn-green ng-btn-lg">
                <i class="fa fa-print"></i> Print Result
            </button>
            <a href="view_report_card.php?sid=<?php echo $studentData['id']; ?>&term=<?php echo urlencode($termUsed); ?>&session=<?php echo urlencode($sessionUsed); ?>" 
               class="ng-btn ng-btn-gold ng-btn-lg" target="_blank">
                <i class="fa fa-file-text"></i> Full Report Card
            </a>
            <a href="check_result.php" class="ng-btn ng-btn-outline ng-btn-lg">
                <i class="fa fa-arrow-left"></i> Check Another
            </a>
        </div>
    </div>
</div>
<?php endif; ?>

</body>
</html>
