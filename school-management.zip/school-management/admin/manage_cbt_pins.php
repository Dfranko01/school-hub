<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

// Stats
$totalPins = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM cbt_activation_pins WHERE used_by_school_id = $schoolId"))['cnt'];
$usedPins = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM cbt_activation_pins WHERE used_by_school_id = $schoolId AND status = 'used'"))['cnt'];
$unusedPins = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM cbt_activation_pins WHERE school_id = $schoolId AND status = 'unused'"))['cnt'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CBT PINs — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php" class="active"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-key"></i> CBT Activation PINs</h1></div>

        <div class="ng-alert ng-alert-success ng-mb-3">
            <i class="fa fa-info-circle"></i> CBT activation PINs are used to <strong>enable CBT exams</strong> for individual subjects. Each PIN activates one subject. 
            <strong>Price: ₦1,000 per PIN.</strong> <a href="purchase_pins.php" style="color:var(--ng-green-dark); font-weight:700;">Purchase PINs →</a>
        </div>

        <div class="stat-cards" style="margin-bottom:24px;">
            <div class="stat-card"><div class="stat-icon green">💳</div><div class="stat-info"><h3><?php echo $totalPins + $unusedPins; ?></h3><p>Total PINs</p></div></div>
            <div class="stat-card"><div class="stat-icon gold">✅</div><div class="stat-info"><h3><?php echo $usedPins; ?></h3><p>Used PINs</p></div></div>
            <div class="stat-card"><div class="stat-icon blue">📋</div><div class="stat-info"><h3><?php echo $unusedPins; ?></h3><p>Available PINs</p></div></div>
        </div>

        <div class="ng-card">
            <div class="ng-card-header" style="display:flex; justify-content:space-between;">
                <h3><i class="fa fa-list"></i> Your CBT PINs</h3>
                <a href="purchase_pins.php" class="ng-btn ng-btn-green ng-btn-sm"><i class="fa fa-shopping-cart"></i> Buy More PINs</a>
            </div>
            <div class="ng-card-body" style="padding:0;">
                <table class="ng-table">
                    <thead><tr><th>#</th><th>PIN</th><th>Subject Activated</th><th>Used Date</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php
                        // Show PINs allocated to this school (unused) + PINs used by this school
                        $pinQ = mysqli_query($con, "SELECT p.*, s.sub_name FROM cbt_activation_pins p LEFT JOIN subject s ON p.used_for_subject_id = s.sub_id WHERE p.school_id = $schoolId OR p.used_by_school_id = $schoolId ORDER BY p.id DESC LIMIT 200");
                        $sn=0; while($p = mysqli_fetch_assoc($pinQ)): $sn++;
                            $statusClass = 'ng-badge-green'; $statusText = 'Available';
                            if($p['status'] == 'used') { $statusClass = 'ng-badge-gold'; $statusText = 'Used'; }
                        ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td style="font-family:monospace; font-weight:700; letter-spacing:1px;"><?php echo $p['pin']; ?></td>
                            <td><?php echo $p['sub_name'] ? '<strong>'.$p['sub_name'].'</strong>' : '<em style="color:var(--ng-text-light);">Not yet used</em>'; ?></td>
                            <td style="font-size:0.82rem;"><?php echo $p['used_at'] ? date('M j, Y g:i A', strtotime($p['used_at'])) : '—'; ?></td>
                            <td><span class="ng-badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if($sn==0): ?><tr><td colspan="5" style="text-align:center; padding:30px; color:var(--ng-text-light);">No CBT PINs allocated yet. <a href="purchase_pins.php" style="color:var(--ng-green); font-weight:600;">Purchase PINs →</a></td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>
