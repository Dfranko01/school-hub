<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = ''; $msgType = 'success';

// Add subject with CBT activation PIN required for enabling
if(isset($_POST['addSubject'])) {
    $subName = mysqli_real_escape_string($con, trim($_POST['sub_name']));
    $classId = intval($_POST['class_id']);
    $duration = intval($_POST['duration']);
    $teacherId = !empty($_POST['teacher_id']) ? intval($_POST['teacher_id']) : 'NULL';
    
    $check = mysqli_query($con, "SELECT sub_id FROM subject WHERE sub_name = '$subName' AND class_id = $classId AND school_id = $schoolId");
    if(mysqli_num_rows($check) > 0) {
        $msg = 'This subject already exists for this class!'; $msgType = 'error';
    } else {
        // Subjects are created Disabled by default. Need CBT activation PIN to enable
        $q = mysqli_query($con, "INSERT INTO subject (school_id, class_id, sub_name, sub_duration, status, teacher_id) VALUES ($schoolId, $classId, '$subName', $duration, 'Disabled', $teacherId)");
        $msg = $q ? "Subject '$subName' added (CBT Disabled — use an activation PIN to enable)" : 'Error: '.mysqli_error($con);
    }
}

// Activate CBT for a subject using an activation PIN
if(isset($_POST['activateCbt'])) {
    $subjectId = intval($_POST['subject_id']);
    $pin = mysqli_real_escape_string($con, trim($_POST['activation_pin']));
    
    // Check PIN validity
    $pinQ = mysqli_query($con, "SELECT * FROM cbt_activation_pins WHERE pin = '$pin' AND status = 'unused' AND (school_id IS NULL OR school_id = $schoolId)");
    if(mysqli_num_rows($pinQ) == 0) {
        $msg = 'Invalid or already used activation PIN!'; $msgType = 'error';
    } else {
        $pinRow = mysqli_fetch_assoc($pinQ);
        // Enable the subject
        mysqli_query($con, "UPDATE subject SET status = 'Enabled' WHERE sub_id = $subjectId AND school_id = $schoolId");
        // Mark PIN as used
        mysqli_query($con, "UPDATE cbt_activation_pins SET status = 'used', used_by_school_id = $schoolId, used_for_subject_id = $subjectId, used_at = NOW() WHERE id = " . $pinRow['id']);
        $msg = 'CBT activated for this subject!';
    }
}

// Disable CBT for a subject (free, no PIN needed)
if(isset($_GET['disable_subject'])) {
    $subId = intval($_GET['disable_subject']);
    mysqli_query($con, "UPDATE subject SET status = 'Disabled' WHERE sub_id = $subId AND school_id = $schoolId");
    header("Location: manage_subjects.php?msg=" . urlencode("CBT disabled for this subject.")); exit;
}

// Delete subject
if(isset($_GET['delete_subject'])) {
    $subId = intval($_GET['delete_subject']);
    mysqli_query($con, "DELETE FROM subject WHERE sub_id = $subId AND school_id = $schoolId");
    header("Location: manage_subjects.php?msg=" . urlencode("Subject deleted.")); exit;
}

// Update subject
if(isset($_POST['updateSubject'])) {
    $subId = intval($_POST['edit_sub_id']);
    $subName = mysqli_real_escape_string($con, trim($_POST['edit_sub_name']));
    $classId = intval($_POST['edit_class_id']);
    $duration = intval($_POST['edit_duration']);
    $teacherId = !empty($_POST['edit_teacher_id']) ? intval($_POST['edit_teacher_id']) : 'NULL';
    $q = mysqli_query($con, "UPDATE subject SET sub_name='$subName', class_id=$classId, sub_duration=$duration, teacher_id=$teacherId WHERE sub_id=$subId AND school_id=$schoolId");
    $msg = $q ? 'Subject updated!' : 'Error: '.mysqli_error($con);
}

$filterClass = isset($_GET['filter_class']) ? intval($_GET['filter_class']) : '';
$filterWhere = $filterClass ? "AND s.class_id = '$filterClass'" : "";
$subjectsQ = mysqli_query($con, "SELECT s.*, c.class as class_name, t.full_name as teacher_name FROM subject s LEFT JOIN class c ON s.class_id = c.id LEFT JOIN teachers t ON s.teacher_id = t.id WHERE s.school_id = $schoolId $filterWhere ORDER BY c.class, s.sub_name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subjects — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        .activate-form { display:inline-flex; gap:6px; align-items:center; }
        .activate-form input { width:160px; padding:6px 10px; border:1px solid var(--ng-border); border-radius:6px; font-family:monospace; font-size:0.85rem; }
        .activate-form button { padding:6px 12px; border-radius:6px; background:var(--ng-green); color:white; border:none; cursor:pointer; font-size:0.82rem; font-weight:600; }
    </style>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php" class="active"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-book"></i> Manage Subjects</h1></div>

        <?php if(!empty($msg) || isset($_GET['msg'])): ?>
            <div class="ng-alert ng-alert-<?php echo $msgType; ?>"><i class="fa fa-<?php echo $msgType=='success'?'check':'exclamation'; ?>-circle"></i> <?php echo !empty($msg) ? $msg : htmlspecialchars($_GET['msg']); ?></div>
        <?php endif; ?>

        <!-- Add Subject -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-header"><h3><i class="fa fa-plus-circle"></i> Add New Subject</h3></div>
            <div class="ng-card-body">
                <form method="post">
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:12px; align-items:end;">
                        <div class="ng-input-group" style="margin-bottom:0;"><label>Subject Name</label><input type="text" name="sub_name" class="ng-input" placeholder="e.g. Mathematics" required></div>
                        <div class="ng-input-group" style="margin-bottom:0;">
                            <label>Class</label>
                            <select name="class_id" class="ng-select" required>
                                <option value="">Select</option>
                                <?php $clsQ = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c = mysqli_fetch_assoc($clsQ)): ?>
                                <option value="<?php echo $c['id']; ?>"><?php echo $c['class']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="ng-input-group" style="margin-bottom:0;"><label>Duration (min)</label><input type="number" name="duration" class="ng-input" value="30" min="5" max="180"></div>
                        <button type="submit" name="addSubject" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-plus"></i> Add Subject</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="ng-alert ng-alert-success ng-mb-3">
            <i class="fa fa-info-circle"></i> <strong>CBT Activation:</strong> New subjects start as <strong>Disabled</strong>. Enter a CBT activation PIN (from your platform admin) to enable CBT for each subject.
        </div>

        <!-- Subjects List -->
        <div class="ng-card">
            <div class="ng-card-header"><h3><i class="fa fa-list"></i> All Subjects</h3></div>
            <div class="ng-card-body" style="padding:0; overflow-x:auto;">
                <table class="ng-table">
                    <thead><tr><th>#</th><th>Subject</th><th>Class</th><th>Duration</th><th>CBT Status</th><th>Activate / Manage</th></tr></thead>
                    <tbody>
                        <?php $sn=0; while($s = mysqli_fetch_assoc($subjectsQ)): $sn++; ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td style="font-weight:600;"><?php echo $s['sub_name']; ?></td>
                            <td><span class="ng-badge ng-badge-green"><?php echo $s['class_name']; ?></span></td>
                            <td><?php echo $s['sub_duration']; ?> min</td>
                            <td>
                                <?php if($s['status'] == 'Enabled'): ?>
                                    <span class="ng-badge ng-badge-green">✅ Enabled</span>
                                <?php else: ?>
                                    <span class="ng-badge ng-badge-red">🔒 Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td style="white-space:nowrap;">
                                <?php if($s['status'] == 'Disabled'): ?>
                                    <form method="post" class="activate-form">
                                        <input type="hidden" name="subject_id" value="<?php echo $s['sub_id']; ?>">
                                        <input type="text" name="activation_pin" placeholder="CBT-XXXX-XXXX-XXXX" required>
                                        <button type="submit" name="activateCbt"><i class="fa fa-key"></i> Activate</button>
                                    </form>
                                <?php else: ?>
                                    <a href="?disable_subject=<?php echo $s['sub_id']; ?>" class="ng-btn ng-btn-outline ng-btn-sm" onclick="return confirm('Disable CBT for this subject?');"><i class="fa fa-ban"></i> Disable</a>
                                <?php endif; ?>
                                <a href="?delete_subject=<?php echo $s['sub_id']; ?>" class="ng-btn ng-btn-danger ng-btn-sm" onclick="return confirm('Delete this subject?');"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if($sn==0): ?><tr><td colspan="6" style="text-align:center; padding:30px; color:var(--ng-text-light);">No subjects found. Add one above.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>
