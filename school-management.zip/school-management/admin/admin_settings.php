<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = ''; $msgType = 'success';
$currentAdmin = $_SESSION['username'];

// Update own profile
if(isset($_POST['updateProfile'])) {
    $newUsername = mysqli_real_escape_string($con, trim($_POST['new_username']));
    $newEmail = mysqli_real_escape_string($con, trim($_POST['new_email']));
    
    // Check duplicate username (exclude self)
    $check = mysqli_query($con, "SELECT id FROM admin WHERE Username = '$newUsername' AND Username != '$currentAdmin' AND school_id = $schoolId");
    if(mysqli_num_rows($check) > 0) {
        $msg = 'Username already taken by another admin!'; $msgType = 'error';
    } else {
        $q = mysqli_query($con, "UPDATE admin SET Username='$newUsername', email='$newEmail' WHERE Username='$currentAdmin' AND school_id=$schoolId");
        if($q) {
            $_SESSION['username'] = $newUsername;
            $currentAdmin = $newUsername;
            $msg = 'Profile updated successfully!';
        } else {
            $msg = 'Error: ' . mysqli_error($con); $msgType = 'error';
        }
    }
}

// Change password
if(isset($_POST['changePassword'])) {
    $currentPw = $_POST['current_password'];
    $newPw = $_POST['new_password'];
    $confirmPw = $_POST['confirm_password'];
    
    if($newPw !== $confirmPw) {
        $msg = 'New passwords do not match!'; $msgType = 'error';
    } elseif(strlen($newPw) < 4) {
        $msg = 'Password must be at least 4 characters!'; $msgType = 'error';
    } else {
        // Verify current password
        $pwHash = sha1($currentPw);
        $pwPlain = addslashes($currentPw);
        $verifyQ = mysqli_query($con, "SELECT id FROM admin WHERE Username='$currentAdmin' AND (Password='$pwHash' OR Password='$pwPlain') AND school_id=$schoolId");
        if(mysqli_num_rows($verifyQ) == 0) {
            $msg = 'Current password is incorrect!'; $msgType = 'error';
        } else {
            $newHash = sha1($newPw);
            mysqli_query($con, "UPDATE admin SET Password='$newHash' WHERE Username='$currentAdmin' AND school_id=$schoolId");
            $msg = 'Password changed successfully!';
        }
    }
}

// Add new admin
if(isset($_POST['addAdmin'])) {
    $adminUser = mysqli_real_escape_string($con, trim($_POST['admin_username']));
    $adminEmail = mysqli_real_escape_string($con, trim($_POST['admin_email']));
    $adminPw = sha1($_POST['admin_password']);
    $adminRole = mysqli_real_escape_string($con, $_POST['admin_role']);
    
    $check = mysqli_query($con, "SELECT id FROM admin WHERE Username='$adminUser' AND school_id=$schoolId");
    if(mysqli_num_rows($check) > 0) {
        $msg = 'Username already exists!'; $msgType = 'error';
    } else {
        $q = mysqli_query($con, "INSERT INTO admin (school_id, Username, Password, email, role) VALUES ($schoolId, '$adminUser', '$adminPw', '$adminEmail', '$adminRole')");
        $msg = $q ? "Admin '$adminUser' created successfully!" : 'Error: ' . mysqli_error($con);
    }
}

// Delete admin
if(isset($_GET['delete_admin'])) {
    $delId = intval($_GET['delete_admin']);
    // Don't allow deleting self
    $selfQ = mysqli_query($con, "SELECT id FROM admin WHERE Username='$currentAdmin'");
    $selfRow = mysqli_fetch_assoc($selfQ);
    if($selfRow && $selfRow['id'] == $delId) {
        $msg = 'You cannot delete your own account!'; $msgType = 'error';
    } else {
        mysqli_query($con, "DELETE FROM admin WHERE id=$delId AND school_id=$schoolId");
        header("Location: admin_settings.php?msg=" . urlencode("Admin deleted."));
        exit;
    }
}

// Get current admin data
$adminQ = mysqli_query($con, "SELECT * FROM admin WHERE Username='$currentAdmin' AND school_id=$schoolId");
$adminData = mysqli_fetch_assoc($adminQ);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php" class="active"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-user-circle"></i> Admin Account Settings</h1></div>

        <?php if(!empty($msg) || isset($_GET['msg'])): ?>
            <div class="ng-alert ng-alert-<?php echo $msgType; ?>"><i class="fa fa-<?php echo $msgType=='success'?'check':'exclamation'; ?>-circle"></i> <?php echo !empty($msg) ? $msg : htmlspecialchars($_GET['msg']); ?></div>
        <?php endif; ?>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px;">
            <!-- Update Profile -->
            <div class="ng-card">
                <div class="ng-card-header"><h3><i class="fa fa-user"></i> My Profile</h3></div>
                <div class="ng-card-body">
                    <form method="post">
                        <div class="ng-input-group">
                            <label>Username</label>
                            <input type="text" name="new_username" class="ng-input" value="<?php echo htmlspecialchars($adminData['Username']); ?>" required>
                        </div>
                        <div class="ng-input-group">
                            <label>Email</label>
                            <input type="email" name="new_email" class="ng-input" value="<?php echo htmlspecialchars($adminData['email'] ?? ''); ?>" placeholder="youremail@school.com">
                        </div>
                        <div class="ng-input-group">
                            <label>Role</label>
                            <input type="text" class="ng-input" value="<?php echo ucfirst($adminData['role'] ?? 'admin'); ?>" disabled style="background:#f0f0f0;">
                        </div>
                        <button type="submit" name="updateProfile" class="ng-btn ng-btn-green ng-btn-block"><i class="fa fa-save"></i> Update Profile</button>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="ng-card">
                <div class="ng-card-header"><h3><i class="fa fa-lock"></i> Change Password</h3></div>
                <div class="ng-card-body">
                    <form method="post">
                        <div class="ng-input-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" class="ng-input" required>
                        </div>
                        <div class="ng-input-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="ng-input" required minlength="4">
                        </div>
                        <div class="ng-input-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" class="ng-input" required>
                        </div>
                        <button type="submit" name="changePassword" class="ng-btn ng-btn-gold ng-btn-block"><i class="fa fa-key"></i> Change Password</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Add New Admin -->
        <div class="ng-card ng-mt-3">
            <div class="ng-card-header"><h3><i class="fa fa-user-plus"></i> Add New Admin</h3></div>
            <div class="ng-card-body">
                <form method="post">
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:16px;">
                        <div class="ng-input-group">
                            <label>Username <span style="color:red;">*</span></label>
                            <input type="text" name="admin_username" class="ng-input" required>
                        </div>
                        <div class="ng-input-group">
                            <label>Password <span style="color:red;">*</span></label>
                            <input type="text" name="admin_password" class="ng-input" required>
                        </div>
                        <div class="ng-input-group">
                            <label>Email</label>
                            <input type="email" name="admin_email" class="ng-input">
                        </div>
                        <div class="ng-input-group">
                            <label>Role</label>
                            <select name="admin_role" class="ng-select">
                                <option value="admin">Admin</option>
                                <option value="super_admin">Super Admin</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" name="addAdmin" class="ng-btn ng-btn-green"><i class="fa fa-plus"></i> Create Admin Account</button>
                </form>
            </div>
        </div>

        <!-- All Admins -->
        <div class="ng-card ng-mt-3">
            <div class="ng-card-header"><h3><i class="fa fa-users"></i> All Admin Accounts</h3></div>
            <div class="ng-card-body" style="padding:0;">
                <table class="ng-table">
                    <thead>
                        <tr><th>#</th><th>Username</th><th>Email</th><th>Role</th><th>Created</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $adminsQ = mysqli_query($con, "SELECT * FROM admin WHERE school_id=$schoolId ORDER BY id");
                        $sn=0; while($a = mysqli_fetch_assoc($adminsQ)): $sn++;
                        ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td style="font-weight:600;">
                                <?php echo $a['Username']; ?>
                                <?php if($a['Username'] == $currentAdmin): ?>
                                    <span class="ng-badge ng-badge-green">You</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $a['email'] ?? '—'; ?></td>
                            <td><span class="ng-badge ng-badge-gold"><?php echo ucfirst($a['role'] ?? 'admin'); ?></span></td>
                            <td style="font-size:0.82rem;"><?php echo date('M d, Y', strtotime($a['RegDate'])); ?></td>
                            <td>
                                <?php if($a['Username'] != $currentAdmin): ?>
                                <a href="?delete_admin=<?php echo $a['id']; ?>" class="ng-btn ng-btn-danger ng-btn-sm" title="Delete admin">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <?php else: ?>
                                <span style="color:#aaa; font-size:0.8rem;">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>
