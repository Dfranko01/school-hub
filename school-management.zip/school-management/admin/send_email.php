<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/smtp_config.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = ''; $msgType = 'success';

// Send email
if(isset($_POST['sendEmail'])) {
    $subject = trim($_POST['email_subject']);
    $body = $_POST['email_body'];
    $recipientType = $_POST['recipient_type'];
    $sent = 0; $failed = 0;
    
    if($recipientType === 'individual') {
        $studentId = intval($_POST['student_id']);
        $stuQ = mysqli_query($con, "SELECT surname, otherNames, email FROM register WHERE id = $studentId AND school_id = $schoolId");
        if($stu = mysqli_fetch_assoc($stuQ)) {
            if(!empty($stu['email'])) {
                $result = sendEmail($stu['email'], $stu['surname'].' '.$stu['otherNames'], $subject, nl2br($body));
                if($result['success']) $sent++; else $failed++;
            } else { $failed++; }
        }
    } elseif($recipientType === 'class') {
        $classId = intval($_POST['class_id']);
        $stuQ = mysqli_query($con, "SELECT surname, otherNames, email FROM register WHERE department = '$classId' AND school_id = $schoolId AND email != '' AND email IS NOT NULL");
        while($stu = mysqli_fetch_assoc($stuQ)) {
            if(!empty($stu['email'])) {
                $result = sendEmail($stu['email'], $stu['surname'].' '.$stu['otherNames'], $subject, nl2br($body));
                if($result['success']) $sent++; else $failed++;
            }
        }
    } else {
        $stuQ = mysqli_query($con, "SELECT surname, otherNames, email FROM register WHERE school_id = $schoolId AND email != '' AND email IS NOT NULL");
        while($stu = mysqli_fetch_assoc($stuQ)) {
            if(!empty($stu['email'])) {
                $result = sendEmail($stu['email'], $stu['surname'].' '.$stu['otherNames'], $subject, nl2br($body));
                if($result['success']) $sent++; else $failed++;
            }
        }
    }
    
    if($sent > 0) {
        $msg = "$sent email(s) sent successfully!" . ($failed > 0 ? " ($failed failed)" : '');
    } else {
        $msg = $failed > 0 ? "Failed to send $failed email(s). Check SMTP settings." : 'No students with email addresses found.';
        $msgType = 'error';
    }
}

$page = isset($_GET['page']) ? $_GET['page'] : 'compose';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Email — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="send_email.php" class="active"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages <?php 
                $unreadQ = mysqli_query($con, "SELECT COUNT(*) as c FROM messages WHERE sender_type='student' AND is_read=0 AND school_id=$schoolId");
                $unread = mysqli_fetch_assoc($unreadQ)['c'];
                if($unread > 0) echo '<span class="ng-badge ng-badge-red" style="margin-left:4px;font-size:0.7rem;">'.$unread.'</span>';
            ?></a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar">
            <h1><i class="fa fa-envelope"></i> Send Email</h1>
            <div>
                <a href="send_email.php" class="ng-btn ng-btn-green ng-btn-sm <?php echo $page=='compose'?'':'ng-btn-outline'; ?>"><i class="fa fa-pencil"></i> Compose</a>
                <a href="send_email.php?page=log" class="ng-btn ng-btn-outline ng-btn-sm <?php echo $page=='log'?'ng-btn-green':''; ?>"><i class="fa fa-history"></i> Email Log</a>
            </div>
        </div>

        <?php if(!empty($msg)): ?>
            <div class="ng-alert ng-alert-<?php echo $msgType; ?>"><i class="fa fa-<?php echo $msgType=='success'?'check-circle':'times-circle'; ?>"></i> <?php echo $msg; ?></div>
        <?php endif; ?>

<?php if($page === 'compose'): ?>
        <!-- Compose Email -->
        <div class="ng-card">
            <div class="ng-card-header"><h3><i class="fa fa-pencil-square-o"></i> Compose Email</h3></div>
            <div class="ng-card-body">
                <form method="POST">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px;">
                        <div class="ng-input-group" style="margin-bottom:0;">
                            <label>Send To</label>
                            <select name="recipient_type" id="recipientType" class="ng-select" required onchange="toggleRecipientFields()">
                                <option value="all">📢 All Students</option>
                                <option value="class">🏫 By Class</option>
                                <option value="individual">👤 Individual Student</option>
                            </select>
                        </div>
                        <div class="ng-input-group" style="margin-bottom:0; display:none;" id="classField">
                            <label>Select Class</label>
                            <select name="class_id" class="ng-select">
                                <option value="">Select Class</option>
                                <?php $clsQ = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c = mysqli_fetch_assoc($clsQ)): ?>
                                <option value="<?php echo $c['id']; ?>"><?php echo $c['class']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="ng-input-group" style="margin-bottom:0; display:none;" id="studentField">
                            <label>Select Student</label>
                            <select name="student_id" class="ng-select">
                                <option value="">Select Student</option>
                                <?php $stuQ = mysqli_query($con, "SELECT id, surname, otherNames, email FROM register WHERE school_id = $schoolId ORDER BY surname"); while($s = mysqli_fetch_assoc($stuQ)): ?>
                                <option value="<?php echo $s['id']; ?>"><?php echo $s['surname'].' '.$s['otherNames']; ?> <?php echo $s['email'] ? '('.$s['email'].')' : '(no email)'; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="ng-input-group">
                        <label><i class="fa fa-tag"></i> Subject</label>
                        <input type="text" name="email_subject" class="ng-input" placeholder="Email subject line..." required>
                    </div>
                    
                    <div class="ng-input-group">
                        <label><i class="fa fa-file-text"></i> Message Body</label>
                        <textarea name="email_body" class="ng-input" rows="10" placeholder="Type your email message here..." style="resize:vertical;" required></textarea>
                    </div>
                    
                    <div class="ng-alert ng-alert-success" style="margin-bottom:16px;">
                        <i class="fa fa-info-circle"></i> Emails will be sent using the SMTP settings configured in School Settings. Make sure SMTP is configured before sending.
                    </div>
                    
                    <button type="submit" name="sendEmail" class="ng-btn ng-btn-green ng-btn-lg" style="padding:14px 40px;">
                        <i class="fa fa-paper-plane"></i> Send Email
                    </button>
                </form>
            </div>
        </div>

<?php elseif($page === 'log'): ?>
        <!-- Email Log -->
        <div class="ng-card">
            <div class="ng-card-header"><h3><i class="fa fa-history"></i> Email History</h3></div>
            <div class="ng-card-body" style="padding:0; overflow-x:auto;">
                <table class="ng-table">
                    <thead>
                        <tr><th>#</th><th>Recipient</th><th>Subject</th><th>Status</th><th>Sent At</th></tr>
                    </thead>
                    <tbody>
                        <?php 
                        $logQ = mysqli_query($con, "SELECT * FROM email_log WHERE school_id = $schoolId ORDER BY sent_at DESC LIMIT 100");
                        $sn = 0;
                        while($log = mysqli_fetch_assoc($logQ)): $sn++;
                        ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($log['recipient_name']); ?></strong><br>
                                <small style="color:var(--ng-text-light);"><?php echo htmlspecialchars($log['recipient_email']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($log['subject']); ?></td>
                            <td>
                                <?php if($log['status'] == 'sent'): ?>
                                    <span class="ng-badge ng-badge-green">✅ Sent</span>
                                <?php else: ?>
                                    <span class="ng-badge ng-badge-red">❌ Failed</span>
                                    <?php if($log['error_message']): ?>
                                    <br><small style="color:var(--ng-danger);"><?php echo htmlspecialchars(substr($log['error_message'], 0, 60)); ?></small>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td style="font-size:0.82rem;"><?php echo date('M d, Y H:i', strtotime($log['sent_at'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if($sn == 0): ?>
                        <tr><td colspan="5" style="text-align:center; padding:30px; color:var(--ng-text-light);">No emails sent yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php endif; ?>
    </main>
</div>

<script>
function toggleRecipientFields() {
    var type = document.getElementById('recipientType').value;
    document.getElementById('classField').style.display = type === 'class' ? 'block' : 'none';
    document.getElementById('studentField').style.display = type === 'individual' ? 'block' : 'none';
}
</script>
</body>
</html>
