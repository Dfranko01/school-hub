<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/paystack_config.php';
ensureTransactionsTable();

$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

// Handle AJAX: create transaction
if(isset($_POST['ajax_create_txn'])) {
    header('Content-Type: application/json');
    $pinType = $_POST['pin_type'] === 'cbt' ? 'cbt' : 'result';
    $quantity = max(1, min(100, intval($_POST['quantity'])));
    $price = $pinType === 'cbt' ? CBT_PIN_PRICE : RESULT_PIN_PRICE;
    $amount = $price * $quantity;
    $reference = 'SH_' . strtoupper(bin2hex(random_bytes(10))) . '_' . time();
    
    $q = mysqli_query($con, "INSERT INTO pin_transactions (school_id, reference, pin_type, quantity, amount) VALUES ($schoolId, '$reference', '$pinType', $quantity, $amount)");
    if($q) {
        echo json_encode(['success' => true, 'reference' => $reference, 'amount' => $amount * 100]); // amount in kobo
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to create transaction']);
    }
    exit;
}

// Stats
$resultPins = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM result_checker_pins WHERE school_id = $schoolId AND student_id IS NULL"))['cnt'];
$cbtPins = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM cbt_activation_pins WHERE school_id = $schoolId AND status = 'unused'"))['cnt'];

// Recent transactions
$txnQ = mysqli_query($con, "SELECT * FROM pin_transactions WHERE school_id = $schoolId ORDER BY created_at DESC LIMIT 20");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase PINs — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <style>
        .purchase-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:30px; }
        .purchase-card { background:white; border-radius:16px; padding:30px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:2px solid transparent; transition:all 0.3s; cursor:pointer; }
        .purchase-card:hover, .purchase-card.selected { border-color:var(--ng-green); transform:translateY(-2px); }
        .purchase-card.selected { background:#f0fdf4; }
        .purchase-card .pin-emoji { font-size:2.5rem; margin-bottom:12px; }
        .purchase-card h3 { font-family:'Outfit',sans-serif; font-size:1.2rem; color:#1a1a2e; margin-bottom:4px; }
        .purchase-card .price { font-size:2rem; font-weight:800; font-family:'Outfit',sans-serif; color:var(--ng-green); margin:8px 0; }
        .purchase-card .desc { font-size:0.85rem; color:#6b7280; line-height:1.5; }
        .purchase-card .stock { font-size:0.8rem; color:var(--ng-green); margin-top:12px; font-weight:600; background:#f0fdf4; padding:6px 12px; border-radius:8px; display:inline-block; }
        .qty-section { background:white; border-radius:16px; padding:30px; box-shadow:0 2px 12px rgba(0,0,0,0.06); margin-bottom:24px; }
        .qty-controls { display:flex; align-items:center; gap:16px; margin:16px 0; }
        .qty-controls button { width:44px; height:44px; border-radius:12px; border:2px solid var(--ng-border); background:white; font-size:1.3rem; font-weight:700; cursor:pointer; transition:all 0.2s; color:#1a1a2e; }
        .qty-controls button:hover { border-color:var(--ng-green); color:var(--ng-green); }
        .qty-controls input { width:80px; text-align:center; font-size:1.4rem; font-weight:700; font-family:'Outfit',sans-serif; border:2px solid var(--ng-border); border-radius:12px; padding:8px; }
        .total-display { font-size:1.3rem; font-weight:700; font-family:'Outfit',sans-serif; color:#1a1a2e; }
        .total-display .amount { color:var(--ng-green); font-size:1.8rem; }
        .pay-btn { width:100%; padding:18px; border:none; border-radius:12px; background:linear-gradient(135deg, #008751, #006340); color:white; font-size:1.1rem; font-weight:700; font-family:'Inter',sans-serif; cursor:pointer; transition:all 0.3s; display:flex; align-items:center; justify-content:center; gap:10px; }
        .pay-btn:hover { transform:translateY(-2px); box-shadow:0 8px 25px rgba(0,135,81,0.35); }
        .pay-btn:disabled { opacity:0.5; cursor:not-allowed; transform:none; box-shadow:none; }
        @media(max-width:768px) {
            .purchase-grid { grid-template-columns:1fr; }
        }
    </style>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php" class="active"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-shopping-cart"></i> Purchase PINs</h1></div>

        <?php if(isset($_GET['payment'])): ?>
            <?php if($_GET['payment'] === 'success'): ?>
                <div class="ng-alert ng-alert-success" style="margin-bottom:20px;">
                    <i class="fa fa-check-circle"></i> <strong>Payment Successful!</strong> 
                    <?php echo intval($_GET['qty']); ?> <?php echo $_GET['type'] === 'cbt' ? 'CBT Activation' : 'Result Checker'; ?> PINs have been generated and added to your account.
                    <br><small>Reference: <?php echo htmlspecialchars($_GET['ref']); ?></small>
                </div>
            <?php elseif($_GET['payment'] === 'failed'): ?>
                <div class="ng-alert ng-alert-error" style="margin-bottom:20px;">
                    <i class="fa fa-exclamation-circle"></i> Payment could not be verified. If you were charged, please contact support with reference: <?php echo htmlspecialchars($_GET['ref'] ?? ''); ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Step 1: Select PIN Type -->
        <h3 style="font-family:'Outfit',sans-serif; margin-bottom:16px; color:#1a1a2e;">
            <i class="fa fa-hand-pointer-o"></i> Step 1: Select PIN Type
        </h3>
        <div class="purchase-grid">
            <div class="purchase-card" id="cardResult" onclick="selectType('result')">
                <div class="pin-emoji">🔑</div>
                <h3>Result Checker PIN</h3>
                <div class="price">₦<?php echo number_format(RESULT_PIN_PRICE); ?></div>
                <div class="desc">Used by students to check their term results. Each PIN allows up to 5 result checks.</div>
                <div class="stock">📦 You have <?php echo $resultPins; ?> unused</div>
            </div>
            <div class="purchase-card" id="cardCbt" onclick="selectType('cbt')">
                <div class="pin-emoji">💻</div>
                <h3>CBT Activation PIN</h3>
                <div class="price">₦<?php echo number_format(CBT_PIN_PRICE); ?></div>
                <div class="desc">Activates CBT exams for one subject. Enter a PIN in CBT setup to enable computer-based testing.</div>
                <div class="stock">📦 You have <?php echo $cbtPins; ?> unused</div>
            </div>
        </div>

        <!-- Step 2: Quantity & Payment -->
        <div class="qty-section" id="qtySection" style="display:none;">
            <h3 style="font-family:'Outfit',sans-serif; margin-bottom:4px; color:#1a1a2e;">
                <i class="fa fa-calculator"></i> Step 2: Select Quantity & Pay
            </h3>
            <p style="color:#6b7280; font-size:0.85rem; margin-bottom:16px;" id="selectedTypeLabel">—</p>

            <div class="qty-controls">
                <button onclick="changeQty(-1)">−</button>
                <input type="number" id="qty" value="5" min="1" max="100" onchange="updateTotal()">
                <button onclick="changeQty(1)">+</button>
                <span style="color:#6b7280; font-size:0.85rem;">PINs</span>
            </div>

            <div class="total-display" style="margin:20px 0;">
                Total: <span class="amount" id="totalAmount">₦0</span>
            </div>

            <button class="pay-btn" id="payBtn" onclick="initPayment()" disabled>
                <i class="fa fa-lock"></i> Pay with Paystack
            </button>
            <p style="text-align:center; margin-top:12px; font-size:0.75rem; color:#9ca3af;">
                <i class="fa fa-shield"></i> Secured by Paystack. PINs are generated instantly after payment.
            </p>
        </div>

        <!-- Transaction History -->
        <div class="ng-card" style="margin-top:20px;">
            <div class="ng-card-header"><h3><i class="fa fa-history"></i> Transaction History</h3></div>
            <div class="ng-card-body" style="padding:0;">
                <table class="ng-table">
                    <thead><tr><th>#</th><th>Reference</th><th>Type</th><th>Qty</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php $sn=0; while($t = mysqli_fetch_assoc($txnQ)): $sn++;
                            $sc = $t['status'] === 'success' ? 'ng-badge-green' : ($t['status'] === 'pending' ? 'ng-badge-gold' : 'ng-badge-red');
                        ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td style="font-family:monospace; font-size:0.78rem;"><?php echo $t['reference']; ?></td>
                            <td><span class="ng-badge <?php echo $t['pin_type']==='cbt'?'ng-badge-blue':'ng-badge-green'; ?>"><?php echo ucfirst($t['pin_type']); ?></span></td>
                            <td><strong><?php echo $t['quantity']; ?></strong></td>
                            <td style="font-weight:600;">₦<?php echo number_format($t['amount']); ?></td>
                            <td><span class="ng-badge <?php echo $sc; ?>"><?php echo ucfirst($t['status']); ?></span></td>
                            <td style="font-size:0.8rem;"><?php echo date('M j, g:i A', strtotime($t['created_at'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if($sn==0): ?><tr><td colspan="7" style="text-align:center; padding:30px; color:#9ca3af;">No transactions yet.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<script src="https://js.paystack.co/v1/inline.js"></script>
<script src="../assets/js/jquery-3.2.1.min.js"></script>
<script>
var selectedType = '';
var prices = { result: <?php echo RESULT_PIN_PRICE; ?>, cbt: <?php echo CBT_PIN_PRICE; ?> };
var labels = { result: '🔑 Result Checker PINs', cbt: '💻 CBT Activation PINs' };
var schoolEmail = '<?php echo addslashes($school['school_email'] ?: 'admin@' . $school['school_slug'] . '.schoolhub.ng'); ?>';

function selectType(type) {
    selectedType = type;
    document.getElementById('cardResult').classList.toggle('selected', type === 'result');
    document.getElementById('cardCbt').classList.toggle('selected', type === 'cbt');
    document.getElementById('qtySection').style.display = 'block';
    document.getElementById('selectedTypeLabel').textContent = 'Selected: ' + labels[type] + ' — ₦' + prices[type].toLocaleString() + ' each';
    document.getElementById('payBtn').disabled = false;
    updateTotal();
    document.getElementById('qtySection').scrollIntoView({ behavior: 'smooth' });
}

function changeQty(delta) {
    var inp = document.getElementById('qty');
    var val = Math.max(1, Math.min(100, parseInt(inp.value) + delta));
    inp.value = val;
    updateTotal();
}

function updateTotal() {
    if(!selectedType) return;
    var qty = Math.max(1, parseInt(document.getElementById('qty').value) || 1);
    var total = qty * prices[selectedType];
    document.getElementById('totalAmount').textContent = '₦' + total.toLocaleString();
}

function initPayment() {
    var qty = parseInt(document.getElementById('qty').value);
    if(!selectedType || qty < 1) return;
    
    var paystackKey = '<?php echo PAYSTACK_PUBLIC_KEY; ?>';
    if(!paystackKey || paystackKey.trim() === '') {
        alert('Paystack payment is not configured yet. Please contact the platform administrator to set up Paystack API keys in the Super Admin panel → Platform Settings.');
        return;
    }
    
    document.getElementById('payBtn').disabled = true;
    document.getElementById('payBtn').innerHTML = '<i class="fa fa-spinner fa-spin"></i> Preparing payment...';

    // Create transaction in DB first
    $.post('purchase_pins.php', {
        ajax_create_txn: 1,
        pin_type: selectedType,
        quantity: qty
    }, function(data) {
        if(data.success) {
            try {
                // Launch Paystack popup
                var handler = PaystackPop.setup({
                    key: paystackKey,
                    email: schoolEmail,
                    amount: data.amount,
                    currency: 'NGN',
                    ref: data.reference,
                    metadata: {
                        school_id: <?php echo $schoolId; ?>,
                        pin_type: selectedType,
                        quantity: qty
                    },
                    callback: function(response) {
                        // Redirect to callback for verification
                        window.location = '../includes/paystack_callback.php?reference=' + response.reference;
                    },
                    onClose: function() {
                        document.getElementById('payBtn').disabled = false;
                        document.getElementById('payBtn').innerHTML = '<i class="fa fa-lock"></i> Pay with Paystack';
                    }
                });
                handler.openIframe();
            } catch(e) {
                alert('Error launching payment: ' + e.message + '\n\nPlease ensure Paystack API keys are correctly configured.');
                document.getElementById('payBtn').disabled = false;
                document.getElementById('payBtn').innerHTML = '<i class="fa fa-lock"></i> Pay with Paystack';
            }
        } else {
            alert('Error creating transaction: ' + (data.error || 'Unknown error. Please try again.'));
            document.getElementById('payBtn').disabled = false;
            document.getElementById('payBtn').innerHTML = '<i class="fa fa-lock"></i> Pay with Paystack';
        }
    }, 'json').fail(function(xhr, status, error) {
        alert('Network error: ' + (error || 'Could not reach server') + '\nPlease check your connection and try again.');
        document.getElementById('payBtn').disabled = false;
        document.getElementById('payBtn').innerHTML = '<i class="fa fa-lock"></i> Pay with Paystack';
    });
}
</script>
</body>
</html>
