<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = ''; $msgType = 'success';

// Reset specific subject for a student
if(isset($_GET['reset_subject'])) {
    $studentId = intval($_GET['reset_subject']);
    $subjectIndex = intval($_GET['sub_index']);
    $subjectName = isset($_GET['sub_name']) ? urldecode($_GET['sub_name']) : '';
    
    if($subjectIndex >= 1 && $subjectIndex <= 9 && !empty($subjectName)) {
        $subField = 'subject' . $subjectIndex;
        $scoreField = $subField . '_score';
        mysqli_query($con, "UPDATE std_result SET $subField='', $scoreField=0 WHERE student_id=$studentId");
        
        $subQ = mysqli_query($con, "SELECT sub_id, class_id FROM subject WHERE sub_name = '" . mysqli_real_escape_string($con, $subjectName) . "' AND school_id = $schoolId LIMIT 1");
        if($subRow = mysqli_fetch_assoc($subQ)) {
            mysqli_query($con, "DELETE FROM dosubject WHERE dostd_id = $studentId AND dosub_id = " . $subRow['sub_id']);
            // Also clear saved answers
            mysqli_query($con, "DELETE FROM cbt_answers WHERE student_id = $studentId AND subject_id = " . $subRow['sub_id']);
        }
        
        header("Location: manage_cbt.php?filter_class=" . (isset($_GET['filter_class']) ? $_GET['filter_class'] : '') . "&msg=" . urlencode("Reset '$subjectName' for student. They can now retake this subject."));
        exit;
    }
}

// Reset ALL subjects for a student
if(isset($_GET['reset_all_student'])) {
    $studentId = intval($_GET['reset_all_student']);
    mysqli_query($con, "UPDATE std_result SET 
        subject1='', subject1_score=0, subject2='', subject2_score=0, subject3='', subject3_score=0,
        subject4='', subject4_score=0, subject5='', subject5_score=0, subject6='', subject6_score=0,
        subject7='', subject7_score=0, subject8='', subject8_score=0, subject9='', subject9_score=0,
        total=0, average=0 WHERE student_id=$studentId");
    mysqli_query($con, "DELETE FROM dosubject WHERE dostd_id = $studentId");
    mysqli_query($con, "DELETE FROM cbt_answers WHERE student_id = $studentId");
    header("Location: manage_cbt.php?filter_class=" . (isset($_GET['filter_class']) ? $_GET['filter_class'] : '') . "&msg=" . urlencode("All CBT results reset for this student."));
    exit;
}

// Reset entire class for a specific subject
if(isset($_GET['reset_class_subject'])) {
    $classId = intval($_GET['reset_class_id']);
    $subjectName = urldecode($_GET['reset_class_subject']);
    $count = 0;
    
    $studentsQ = mysqli_query($con, "SELECT id FROM register WHERE department = '$classId' AND school_id = $schoolId");
    $subQ = mysqli_query($con, "SELECT sub_id FROM subject WHERE sub_name = '" . mysqli_real_escape_string($con, $subjectName) . "' AND school_id = $schoolId LIMIT 1");
    $subRow = $subQ ? mysqli_fetch_assoc($subQ) : null;
    
    while($s = mysqli_fetch_assoc($studentsQ)) {
        $sid = $s['id'];
        $stdResult = mysqli_query($con, "SELECT * FROM std_result WHERE student_id=$sid");
        $sr = mysqli_fetch_assoc($stdResult);
        if($sr) {
            for($i=1; $i<=9; $i++) {
                if(trim($sr['subject'.$i]) == trim($subjectName)) {
                    $subField = 'subject'.$i;
                    $scoreField = $subField.'_score';
                    mysqli_query($con, "UPDATE std_result SET $subField='', $scoreField=0 WHERE student_id=$sid");
                    break;
                }
            }
        }
        if($subRow) {
            mysqli_query($con, "DELETE FROM dosubject WHERE dostd_id = $sid AND dosub_id = " . $subRow['sub_id']);
            mysqli_query($con, "DELETE FROM cbt_answers WHERE student_id = $sid AND subject_id = " . $subRow['sub_id']);
        }
        $count++;
    }
    header("Location: manage_cbt.php?filter_class=$classId&msg=" . urlencode("Reset '$subjectName' for $count students. They can now retake this subject."));
    exit;
}

// Import CBT scores to term results
if(isset($_GET['do_import'])) {
    $term = isset($_GET['import_term']) ? $_GET['import_term'] : $school['current_term'];
    $session = isset($_GET['import_session']) ? $_GET['import_session'] : $school['current_session'];
    $imported = 0;
    
    $cbtQ = mysqli_query($con, "SELECT sr.*, r.department FROM std_result sr JOIN register r ON sr.student_id = r.id WHERE sr.school_id = $schoolId");
    while($cbt = mysqli_fetch_assoc($cbtQ)) {
        $studentId = $cbt['student_id'];
        $classId = $cbt['department'];
        
        for($i = 1; $i <= 9; $i++) {
            $subName = trim($cbt['subject'.$i]);
            $subScore = intval($cbt['subject'.$i.'_score']);
            if(empty($subName) || $subScore == 0) continue;
            
            $subQ = mysqli_query($con, "SELECT sub_id FROM subject WHERE sub_name = '" . mysqli_real_escape_string($con, $subName) . "' AND school_id = $schoolId LIMIT 1");
            if(mysqli_num_rows($subQ) == 0) continue;
            $subRow = mysqli_fetch_assoc($subQ);
            $subjectId = $subRow['sub_id'];
            $ca1Score = round(($subScore / 100) * 20);
            
            $existQ = mysqli_query($con, "SELECT id, ca2, exam_score FROM term_results WHERE student_id=$studentId AND subject_id=$subjectId AND class_id='$classId' AND term='$term' AND session='$session'");
            if(mysqli_num_rows($existQ) > 0) {
                $ef = mysqli_fetch_assoc($existQ);
                $total = $ca1Score + $ef['ca2'] + $ef['exam_score'];
                $grade = getGrade($total);
                $remark = getGradeRemark($grade);
                mysqli_query($con, "UPDATE term_results SET ca1=$ca1Score, total=$total, grade='$grade', remark='$remark' WHERE id=".$ef['id']);
            } else {
                $grade = getGrade($ca1Score);
                $remark = getGradeRemark($grade);
                mysqli_query($con, "INSERT INTO term_results (student_id, subject_id, class_id, term, session, ca1, ca2, ca3, exam_score, total, grade, remark) VALUES ($studentId, $subjectId, '$classId', '$term', '$session', $ca1Score, 0, 0, 0, $ca1Score, '$grade', '$remark')");
            }
            $imported++;
        }
    }
    header("Location: manage_cbt.php?msg=" . urlencode("$imported CBT subject scores imported into term results as CA1!"));
    exit;
}

$filterClass = isset($_GET['filter_class']) ? intval($_GET['filter_class']) : '';

// View student detail
$viewStudent = isset($_GET['view_student']) ? intval($_GET['view_student']) : 0;
$viewSubject = isset($_GET['view_subject']) ? intval($_GET['view_subject']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CBT Management — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        .score-badge { display:inline-block; padding:4px 12px; border-radius:20px; font-size:0.82rem; font-weight:600; }
        .score-high { background:#dcfce7; color:#15803d; }
        .score-mid { background:#fef9c3; color:#a16207; }
        .score-low { background:#fee2e2; color:#dc2626; }
        .subject-row { border-left:3px solid var(--ng-green-light); }
        .answer-correct { background:#f0fdf4; border-left:3px solid #22c55e; }
        .answer-wrong { background:#fef2f2; border-left:3px solid #ef4444; }
        .question-text { font-size:0.92rem; font-weight:500; line-height:1.5; }
        .option-list { margin:8px 0 0; padding:0; list-style:none; }
        .option-list li { padding:4px 12px; margin:3px 0; border-radius:6px; font-size:0.85rem; }
        .option-list li.correct-option { background:#dcfce7; color:#15803d; font-weight:600; }
        .option-list li.wrong-option { background:#fee2e2; color:#dc2626; text-decoration:line-through; }
        .option-list li.neutral-option { background:#f8f9fa; color:#6b7280; }
    </style>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php" class="active"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-laptop"></i> CBT Results Management</h1></div>

        <?php if(!empty($msg) || isset($_GET['msg'])): ?>
            <div class="ng-alert ng-alert-<?php echo $msgType; ?>"><i class="fa fa-check-circle"></i> <?php echo !empty($msg) ? $msg : htmlspecialchars($_GET['msg']); ?></div>
        <?php endif; ?>

<?php if($viewStudent && $viewSubject): ?>
        <?php
        // === STUDENT CBT DETAIL VIEW ===
        $studentQ = mysqli_query($con, "SELECT r.*, c.class as class_name FROM register r LEFT JOIN class c ON r.department = c.id WHERE r.id = $viewStudent AND r.school_id = $schoolId");
        $student = mysqli_fetch_assoc($studentQ);
        $subjectQ = mysqli_query($con, "SELECT * FROM subject WHERE sub_id = $viewSubject AND school_id = $schoolId");
        $subject = mysqli_fetch_assoc($subjectQ);
        
        if($student && $subject):
            // Get student's answers for this subject
            $answersQ = mysqli_query($con, "SELECT ca.*, q.question_desc, q.option1, q.option2, q.option3, q.option4, q.true_answer 
                FROM cbt_answers ca 
                JOIN question q ON ca.question_id = q.id 
                WHERE ca.student_id = $viewStudent AND ca.subject_id = $viewSubject 
                ORDER BY ca.id");
            $totalAnswers = $answersQ ? mysqli_num_rows($answersQ) : 0;
            $correctCount = 0;
            $wrongCount = 0;
            if($totalAnswers > 0) {
                $answersData = [];
                while($row = mysqli_fetch_assoc($answersQ)) {
                    $answersData[] = $row;
                    if($row['is_correct']) $correctCount++; else $wrongCount++;
                }
            }
        ?>
        <a href="manage_cbt.php?filter_class=<?php echo $student['department']; ?>" class="ng-btn ng-btn-outline ng-mb-3" style="display:inline-block;">
            <i class="fa fa-arrow-left"></i> Back to Results
        </a>

        <div class="ng-card ng-mb-3">
            <div class="ng-card-header">
                <h3><i class="fa fa-user"></i> CBT Detail — <?php echo $student['surname'] . ' ' . $student['otherNames']; ?></h3>
            </div>
            <div class="ng-card-body">
                <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:16px; margin-bottom:20px;">
                    <div style="padding:16px; background:var(--ng-bg); border-radius:8px; text-align:center;">
                        <div style="font-weight:800; font-size:1.3rem; color:var(--ng-green-dark);"><?php echo $subject['sub_name']; ?></div>
                        <div style="font-size:0.8rem; color:var(--ng-text-light);">Subject</div>
                    </div>
                    <div style="padding:16px; background:#f0fdf4; border-radius:8px; text-align:center;">
                        <div style="font-weight:800; font-size:1.5rem; color:#22c55e;"><?php echo $correctCount; ?></div>
                        <div style="font-size:0.8rem; color:var(--ng-text-light);">Correct</div>
                    </div>
                    <div style="padding:16px; background:#fef2f2; border-radius:8px; text-align:center;">
                        <div style="font-weight:800; font-size:1.5rem; color:#ef4444;"><?php echo $wrongCount; ?></div>
                        <div style="font-size:0.8rem; color:var(--ng-text-light);">Wrong</div>
                    </div>
                    <div style="padding:16px; background:#eff6ff; border-radius:8px; text-align:center;">
                        <div style="font-weight:800; font-size:1.5rem; color:#3b82f6;"><?php echo $totalAnswers; ?></div>
                        <div style="font-size:0.8rem; color:var(--ng-text-light);">Total Questions</div>
                    </div>
                </div>
                <div style="display:flex; gap:12px;">
                    <span class="ng-badge ng-badge-green"><?php echo $student['class_name']; ?></span>
                    <span class="ng-badge ng-badge-gold"><?php echo $student['examNumber']; ?></span>
                    <?php $pct = $totalAnswers > 0 ? round(($correctCount/$totalAnswers)*100) : 0; ?>
                    <span class="score-badge <?php echo $pct >= 70 ? 'score-high' : ($pct >= 50 ? 'score-mid' : 'score-low'); ?>"><?php echo $pct; ?>%</span>
                </div>
            </div>
        </div>

        <?php if($totalAnswers > 0): ?>
        <div class="ng-card">
            <div class="ng-card-header"><h3><i class="fa fa-list-ol"></i> Question-by-Question Breakdown</h3></div>
            <div class="ng-card-body" style="padding:0;">
                <?php $qn = 0; foreach($answersData as $ans): $qn++; ?>
                <div style="padding:16px 24px; border-bottom:1px solid var(--ng-border);" class="<?php echo $ans['is_correct'] ? 'answer-correct' : 'answer-wrong'; ?>">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                        <div style="flex:1;">
                            <p class="question-text">
                                <strong>Q<?php echo $qn; ?>.</strong> <?php echo htmlspecialchars($ans['question_desc']); ?>
                            </p>
                            <ul class="option-list">
                                <?php 
                                $options = ['A' => $ans['option1'], 'B' => $ans['option2'], 'C' => $ans['option3'], 'D' => $ans['option4']];
                                foreach($options as $letter => $optText):
                                    $isStudentChoice = (strtolower(trim($optText)) == strtolower(trim($ans['student_answer'])));
                                    $isCorrectOption = (strtolower(trim($optText)) == strtolower(trim($ans['correct_answer'])));
                                    $liClass = 'neutral-option';
                                    if($isCorrectOption) $liClass = 'correct-option';
                                    elseif($isStudentChoice && !$ans['is_correct']) $liClass = 'wrong-option';
                                ?>
                                <li class="<?php echo $liClass; ?>">
                                    <strong><?php echo $letter; ?>.</strong> <?php echo htmlspecialchars($optText); ?>
                                    <?php if($isCorrectOption): ?> ✅<?php endif; ?>
                                    <?php if($isStudentChoice && !$ans['is_correct']): ?> ❌ (Student's answer)<?php endif; ?>
                                    <?php if($isStudentChoice && $ans['is_correct']): ?> ✅ (Student's answer)<?php endif; ?>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <div style="margin-left:16px; min-width:60px; text-align:center;">
                            <?php if($ans['is_correct']): ?>
                                <span style="font-size:1.5rem;">✅</span><br>
                                <small style="color:#22c55e; font-weight:600;">Correct</small>
                            <?php else: ?>
                                <span style="font-size:1.5rem;">❌</span><br>
                                <small style="color:#ef4444; font-weight:600;">Wrong</small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="ng-card">
            <div class="ng-card-body" style="text-align:center; padding:40px;">
                <p style="font-size:1.2rem; color:var(--ng-text-light);">📋 No detailed answers found for this student's exam.</p>
                <p style="font-size:0.85rem; color:var(--ng-text-light); margin-top:8px;">
                    Answer details are only available for exams taken after the tracking feature was enabled.<br>
                    The student will need to retake the exam for question-by-question details to appear.
                </p>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; /* end student && subject */ ?>

<?php else: ?>
        <!-- ====== MAIN CBT RESULTS VIEW ====== -->
        
        <!-- Import CBT to Term Results -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-header"><h3><i class="fa fa-upload"></i> Import CBT Scores → Term Results (as CA1)</h3></div>
            <div class="ng-card-body">
                <div class="ng-alert ng-alert-success" style="margin-bottom:16px;">
                    <i class="fa fa-info-circle"></i> Imports each student's CBT subject scores as CA1 marks (scaled to /20) into term results.
                </div>
                <form method="get" style="display:flex; gap:12px; align-items:end;">
                    <input type="hidden" name="do_import" value="1">
                    <div class="ng-input-group" style="margin-bottom:0; flex:1;">
                        <label>Term</label>
                        <select name="import_term" class="ng-select">
                            <?php foreach(['1st Term','2nd Term','3rd Term'] as $t): ?>
                            <option value="<?php echo $t; ?>" <?php echo $t==$school['current_term']?'selected':''; ?>><?php echo $t; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="ng-input-group" style="margin-bottom:0; flex:1;">
                        <label>Session</label>
                        <input type="text" name="import_session" class="ng-input" value="<?php echo $school['current_session']; ?>">
                    </div>
                    <button type="submit" class="ng-btn ng-btn-gold" style="height:52px;">
                        <i class="fa fa-download"></i> Import to Term Results
                    </button>
                </form>
            </div>
        </div>

        <!-- Filter -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-body" style="padding:12px 16px;">
                <form method="get" style="display:flex; gap:12px; align-items:end;">
                    <div class="ng-input-group" style="margin-bottom:0; flex:1;">
                        <label>Filter by Class</label>
                        <select name="filter_class" class="ng-select">
                            <option value="">All Classes</option>
                            <?php $clsQ=mysqli_query($con,"SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c=mysqli_fetch_assoc($clsQ)): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo $filterClass==$c['id']?'selected':''; ?>><?php echo $c['class']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-filter"></i> Filter</button>
                </form>
            </div>
        </div>

        <?php if($filterClass): ?>
        <!-- Class-wide subject reset -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-header"><h3><i class="fa fa-refresh"></i> Bulk Reset for <?php echo getClassName($filterClass); ?></h3></div>
            <div class="ng-card-body">
                <p style="font-size:0.85rem; color:var(--ng-text-light); margin-bottom:12px;">Reset a specific subject for all students in this class:</p>
                <form method="get" style="display:flex; gap:12px; align-items:end;">
                    <input type="hidden" name="reset_class_id" value="<?php echo $filterClass; ?>">
                    <div class="ng-input-group" style="margin-bottom:0; flex:1;">
                        <label>Subject to Reset</label>
                        <select name="reset_class_subject" class="ng-select" required>
                            <option value="">Select Subject</option>
                            <?php 
                            $subjectsQ = mysqli_query($con, "SELECT sub_name FROM subject WHERE class_id = '$filterClass' AND school_id = $schoolId ORDER BY sub_name");
                            while($sub = mysqli_fetch_assoc($subjectsQ)):
                            ?>
                            <option value="<?php echo $sub['sub_name']; ?>"><?php echo $sub['sub_name']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="ng-btn ng-btn-danger" style="height:52px;">
                        <i class="fa fa-refresh"></i> Reset Subject for Class
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- CBT Results — Per Subject View -->
        <div class="ng-card">
            <div class="ng-card-header"><h3><i class="fa fa-list"></i> Student CBT Scores (Per Subject)</h3></div>
            <div class="ng-card-body" style="padding:0; overflow-x:auto;">
                <table class="ng-table">
                    <thead>
                        <tr><th>#</th><th>Student</th><th>Class</th><th>Subject</th><th>Score</th><th>Status</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $where = $filterClass ? "WHERE r.department = '$filterClass' AND r.school_id = $schoolId" : "WHERE r.school_id = $schoolId";
                        $cbtQ = mysqli_query($con, "SELECT sr.*, r.surname, r.otherNames, r.examNumber, r.department, c.class as class_name 
                            FROM std_result sr 
                            JOIN register r ON sr.student_id = r.id 
                            LEFT JOIN class c ON r.department = c.id 
                            $where
                            ORDER BY c.class, r.surname, r.otherNames");
                        $sn=0; $hasRows = false;
                        if($cbtQ && mysqli_num_rows($cbtQ) > 0):
                            while($row = mysqli_fetch_assoc($cbtQ)):
                                $studentHasSubjects = false;
                                for($i=1; $i<=9; $i++):
                                    $subName = trim($row['subject'.$i]);
                                    $subScore = intval($row['subject'.$i.'_score']);
                                    if(empty($subName)) continue;
                                    $studentHasSubjects = true;
                                    $hasRows = true;
                                    $sn++;
                                    
                                    $scoreClass = 'score-low';
                                    if($subScore >= 70) $scoreClass = 'score-high';
                                    elseif($subScore >= 50) $scoreClass = 'score-mid';
                                    
                                    // Get subject ID for view link
                                    $subIdQ = mysqli_query($con, "SELECT sub_id FROM subject WHERE sub_name = '" . mysqli_real_escape_string($con, $subName) . "' AND school_id = $schoolId LIMIT 1");
                                    $subIdRow = $subIdQ ? mysqli_fetch_assoc($subIdQ) : null;
                                    $subjectId = $subIdRow ? $subIdRow['sub_id'] : 0;
                        ?>
                        <tr class="subject-row">
                            <td><?php echo $sn; ?></td>
                            <td style="font-weight:600;">
                                <?php echo $row['surname'].' '.$row['otherNames']; ?>
                                <br><small style="color:var(--ng-text-light);"><?php echo $row['examNumber']; ?></small>
                            </td>
                            <td><span class="ng-badge ng-badge-green"><?php echo $row['class_name']; ?></span></td>
                            <td style="font-weight:500;"><?php echo $subName; ?></td>
                            <td><span class="score-badge <?php echo $scoreClass; ?>"><?php echo $subScore; ?>%</span></td>
                            <td><span class="ng-badge ng-badge-green">Completed</span></td>
                            <td style="white-space:nowrap;">
                                <?php if($subjectId): ?>
                                <a href="?view_student=<?php echo $row['student_id']; ?>&view_subject=<?php echo $subjectId; ?>" 
                                   class="ng-btn ng-btn-outline ng-btn-sm" title="View answers">
                                    <i class="fa fa-eye"></i>
                                </a>
                                <?php endif; ?>
                                <a href="?reset_subject=<?php echo $row['student_id']; ?>&sub_index=<?php echo $i; ?>&sub_name=<?php echo urlencode($subName); ?>&filter_class=<?php echo $filterClass; ?>" 
                                   class="ng-btn ng-btn-danger ng-btn-sm" title="Reset this subject">
                                    <i class="fa fa-refresh"></i>
                                </a>
                            </td>
                        </tr>
                        <?php
                                endfor;
                                if(!$studentHasSubjects): $sn++;
                        ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td style="font-weight:600;"><?php echo $row['surname'].' '.$row['otherNames']; ?><br><small style="color:var(--ng-text-light);"><?php echo $row['examNumber']; ?></small></td>
                            <td><span class="ng-badge ng-badge-green"><?php echo $row['class_name']; ?></span></td>
                            <td colspan="3" style="color:var(--ng-text-light); font-style:italic;">No subjects taken yet</td>
                            <td>—</td>
                        </tr>
                        <?php endif; ?>
                        <?php endwhile; endif; ?>
                        <?php if(!$hasRows && $sn == 0): ?>
                        <tr><td colspan="7" style="text-align:center; padding:30px; color:var(--ng-text-light);">No CBT results found. Students will appear here after taking exams.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php endif; /* end main vs detail view */ ?>
    </main>
</div>
</body>
</html>
