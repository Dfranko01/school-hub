<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();

// Check admin session
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) {
    header("Location: index.php");
    exit;
}

// Include add_question handler
include '../includes/add_question.php';

// Delete question
if(isset($_GET['delete_q'])) {
    $delQId = intval($_GET['delete_q']);
    mysqli_query($con, "DELETE FROM question WHERE id = $delQId AND school_id = $schoolId");
    $redirect = 'question_portal.php?page=questions&success=' . urlencode('Question deleted!');
    if(isset($_GET['filter_class'])) $redirect .= '&filter_class=' . $_GET['filter_class'];
    if(isset($_GET['filter_subject'])) $redirect .= '&filter_subject=' . $_GET['filter_subject'];
    header("Location: $redirect");
    exit;
}

// Bulk delete questions
if(isset($_POST['bulk_delete_questions']) && !empty($_POST['question_ids'])) {
    $ids = array_map('intval', $_POST['question_ids']);
    $idList = implode(',', $ids);
    mysqli_query($con, "DELETE FROM question WHERE id IN ($idList) AND school_id = $schoolId");
    $count = mysqli_affected_rows($con);
    header("Location: question_portal.php?page=questions&success=" . urlencode("$count question(s) deleted successfully!"));
    exit;
}

// Get stats
$totalStudents = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM register WHERE school_id = $schoolId"))['cnt'];
$totalSubjects = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM subject WHERE school_id = $schoolId"))['cnt'];
$totalTeachers = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM teachers WHERE school_id = $schoolId"))['cnt'];
$totalQuestions = mysqli_fetch_assoc(mysqli_query($con, "SELECT COUNT(*) as cnt FROM question WHERE school_id = $schoolId"))['cnt'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $school['school_name']; ?> — Admin Dashboard</title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <script src="../ckeditor/ckeditor.js"></script>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>

<div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="sidebar-header">
            <img src="../<?php echo $school['school_logo']; ?>" alt="Logo">
            <h3><?php echo $school['school_name']; ?></h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php" class="active"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="admin-content">
        <div class="admin-topbar">
            <div>
                <button class="ng-btn ng-btn-sm ng-btn-outline d-lg-none" onclick="document.getElementById('adminSidebar').classList.toggle('open')" style="margin-right:12px;">
                    <i class="fa fa-bars"></i>
                </button>
                <h1 style="display:inline;">Welcome, <?php echo $_SESSION['username']; ?>!</h1>
            </div>
            <span class="ng-badge ng-badge-green"><?php echo $school['current_term']; ?> | <?php echo $school['current_session']; ?></span>
        </div>

        <?php
        $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
        
        if($page == 'dashboard'):
        ?>
        <!-- Dashboard Stats -->
        <div class="stat-cards">
            <div class="stat-card">
                <div class="stat-icon green">👨‍🎓</div>
                <div class="stat-info">
                    <h3><?php echo $totalStudents; ?></h3>
                    <p>Total Students</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon gold">📚</div>
                <div class="stat-info">
                    <h3><?php echo $totalSubjects; ?></h3>
                    <p>Total Subjects</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon blue">👩‍🏫</div>
                <div class="stat-info">
                    <h3><?php echo $totalTeachers; ?></h3>
                    <p>Total Teachers</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon red">❓</div>
                <div class="stat-info">
                    <h3><?php echo $totalQuestions; ?></h3>
                    <p>CBT Questions</p>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="ng-card">
            <div class="ng-card-header">
                <h3><i class="fa fa-bolt"></i> Quick Actions</h3>
            </div>
            <div class="ng-card-body">
                <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(200px, 1fr)); gap:16px;">
                    <a href="question_portal.php?page=questions" class="ng-btn ng-btn-green ng-btn-block">
                        <i class="fa fa-plus"></i> Add CBT Question
                    </a>
                    <a href="enter_results.php" class="ng-btn ng-btn-gold ng-btn-block">
                        <i class="fa fa-pencil"></i> Enter Results
                    </a>
                    <a href="view_results.php" class="ng-btn ng-btn-outline ng-btn-block">
                        <i class="fa fa-eye"></i> View Results
                    </a>
                    <a href="school_settings.php" class="ng-btn ng-btn-outline ng-btn-block">
                        <i class="fa fa-cog"></i> School Settings
                    </a>
                </div>
            </div>
        </div>

        <?php elseif($page == 'questions'): ?>

        <?php if(isset($_GET['success'])): ?>
            <div class="ng-alert ng-alert-success"><i class="fa fa-check-circle"></i> <?php echo htmlspecialchars($_GET['success']); ?></div>
        <?php endif; ?>
        <?php if(isset($_GET['error'])): ?>
            <div class="ng-alert ng-alert-error"><i class="fa fa-exclamation-circle"></i> <?php echo htmlspecialchars($_GET['error']); ?></div>
        <?php endif; ?>
        <?php if(isset($_GET['errors'])): 
            $errs = explode('|', $_GET['errors']); 
            foreach($errs as $e): ?>
            <div class="ng-alert ng-alert-warning" style="font-size:0.85rem;"><i class="fa fa-warning"></i> <?php echo htmlspecialchars($e); ?></div>
        <?php endforeach; endif; ?>

        <!-- Tab Buttons -->
        <div style="display:flex; gap:8px; margin-bottom:20px;">
            <button class="ng-btn ng-btn-green" onclick="showTab('single')" id="tab-single">
                <i class="fa fa-plus"></i> Single Upload
            </button>
            <button class="ng-btn ng-btn-outline" onclick="showTab('bulk')" id="tab-bulk">
                <i class="fa fa-file-text-o"></i> Bulk Upload (.txt)
            </button>
            <button class="ng-btn ng-btn-outline" onclick="showTab('manage')" id="tab-manage">
                <i class="fa fa-list"></i> All Questions
            </button>
        </div>

        <!-- SINGLE UPLOAD TAB -->
        <div id="panel-single">
        <div class="ng-card">
            <div class="ng-card-header">
                <h3><i class="fa fa-upload"></i> Upload Single CBT Question</h3>
            </div>
            <div class="ng-card-body">
                <form action="" method="post" enctype="multipart/form-data">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                        <div class="ng-input-group">
                            <label>Select Class</label>
                            <select name="classGroup" id="classGroup" class="ng-select" onchange="showSubject(this.value)" required>
                                <option value="">Select Class</option>
                                <?php
                                    $classQ = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id");
                                    while($cls = mysqli_fetch_array($classQ)):
                                ?>
                                <option value="<?php echo $cls['id']; ?>"><?php echo $cls['class']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="ng-input-group">
                            <label>Select Subject</label>
                            <select name="classSubject" id="classSubject" class="ng-select" required>
                                <option value="">— Select class first —</option>
                            </select>
                        </div>
                    </div>

                    <div class="ng-input-group">
                        <label>Question</label>
                        <textarea name="questionDescription" id="questionDescription" rows="4" class="ng-input" placeholder="Enter the question..." required></textarea>
                    </div>
                    <script>CKEDITOR.replace('questionDescription');</script>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                        <div class="ng-input-group">
                            <label>Option A</label>
                            <input type="text" name="option1" class="ng-input" placeholder="Option A" required>
                        </div>
                        <div class="ng-input-group">
                            <label>Option B</label>
                            <input type="text" name="option2" class="ng-input" placeholder="Option B" required>
                        </div>
                        <div class="ng-input-group">
                            <label>Option C</label>
                            <input type="text" name="option3" class="ng-input" placeholder="Option C" required>
                        </div>
                        <div class="ng-input-group">
                            <label>Option D</label>
                            <input type="text" name="option4" class="ng-input" placeholder="Option D" required>
                        </div>
                    </div>

                    <div class="ng-input-group">
                        <label>Correct Answer</label>
                        <input type="text" name="trueAnswer" class="ng-input" placeholder="Enter the correct answer exactly as it appears above" required>
                    </div>

                    <button type="submit" name="btn-submit" class="ng-btn ng-btn-green ng-btn-lg ng-btn-block">
                        <i class="fa fa-upload"></i> Upload Question
                    </button>
                </form>
            </div>
        </div>
        </div>

        <!-- BULK UPLOAD TAB -->
        <div id="panel-bulk" style="display:none;">
        <div class="ng-card ng-mb-3">
            <div class="ng-card-header">
                <h3><i class="fa fa-file-text-o"></i> Bulk Upload Questions from .txt File</h3>
            </div>
            <div class="ng-card-body">
                <div class="ng-alert ng-alert-success" style="margin-bottom:20px;">
                    <i class="fa fa-info-circle"></i>
                    <div>
                        <strong>Template Format:</strong> Use <code>---</code> to separate each question block. Each block has: <code>Q:</code> (question), <code>A:</code> <code>B:</code> <code>C:</code> <code>D:</code> (options), <code>ANSWER:</code> (correct letter A/B/C/D).
                        <a href="../templates/question_template.txt" download style="margin-left:8px; font-weight:700; color:var(--ng-green);">
                            <i class="fa fa-download"></i> Download Template
                        </a>
                    </div>
                </div>

                <div style="background:#F1F5F9; border-radius:var(--ng-radius-sm); padding:16px; margin-bottom:20px; font-family:monospace; font-size:0.82rem; color:#475569; line-height:1.8; white-space:pre;">---
Q: What is the capital of Nigeria?
A: Lagos
B: Abuja
C: Kano
D: Ibadan
ANSWER: B
---
Q: What is 2 + 2?
A: 3
B: 4
C: 5
D: 6
ANSWER: B
---</div>

                <form action="../includes/bulk_upload.php" method="post" enctype="multipart/form-data">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                        <div class="ng-input-group">
                            <label>Select Class</label>
                            <select name="class_id" id="bulkClassGroup" class="ng-select" onchange="showBulkSubject(this.value)" required>
                                <option value="">Select Class</option>
                                <?php
                                    $classQ2 = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id");
                                    while($cls2 = mysqli_fetch_array($classQ2)):
                                ?>
                                <option value="<?php echo $cls2['id']; ?>"><?php echo $cls2['class']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="ng-input-group">
                            <label>Select Subject</label>
                            <select name="subject_id" id="bulkClassSubject" class="ng-select" required>
                                <option value="">— Select class first —</option>
                            </select>
                        </div>
                    </div>

                    <div class="ng-input-group">
                        <label><i class="fa fa-file-text-o"></i> Upload .txt File</label>
                        <input type="file" name="questionFile" class="ng-input" accept=".txt" required>
                    </div>
                    <p style="font-size:0.8rem; color:var(--ng-text-light); margin-bottom:16px;">Maximum file size: 2MB. Only .txt files are accepted.</p>

                    <button type="submit" name="bulkUpload" class="ng-btn ng-btn-gold ng-btn-lg ng-btn-block">
                        <i class="fa fa-cloud-upload"></i> Upload All Questions
                    </button>
                </form>
            </div>
        </div>
        </div>

        <!-- ALL QUESTIONS TAB -->
        <div id="panel-manage" style="display:none;">
        <div class="ng-card ng-mb-3">
            <div class="ng-card-body">
                <form method="get" style="display:grid; grid-template-columns:1fr 1fr auto; gap:12px; align-items:end;">
                    <input type="hidden" name="page" value="questions">
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Filter by Class</label>
                        <select name="filter_class" class="ng-select" id="filterClass">
                            <option value="">All Classes</option>
                            <?php
                                $classQ3 = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id");
                                while($cls3 = mysqli_fetch_array($classQ3)):
                            ?>
                            <option value="<?php echo $cls3['id']; ?>" <?php echo (isset($_GET['filter_class']) && $_GET['filter_class']==$cls3['id']) ? 'selected':''; ?>>
                                <?php echo $cls3['class']; ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Filter by Subject</label>
                        <select name="filter_subject" class="ng-select" id="filterSubject">
                            <option value="">All Subjects</option>
                            <?php
                                $subQ = mysqli_query($con, "SELECT DISTINCT s.sub_id, s.sub_name, c.class as class_name FROM subject s LEFT JOIN class c ON s.class_id = c.id WHERE s.school_id = $schoolId ORDER BY c.id, s.sub_name");
                                while($sub = mysqli_fetch_assoc($subQ)):
                            ?>
                            <option value="<?php echo $sub['sub_id']; ?>" <?php echo (isset($_GET['filter_subject']) && $_GET['filter_subject']==$sub['sub_id']) ? 'selected':''; ?>>
                                <?php echo $sub['sub_name']; ?> (<?php echo $sub['class_name']; ?>)
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-filter"></i> Filter</button>
                </form>
            </div>
        </div>

        <?php
            $filterWhere = "1=1";
            if(isset($_GET['filter_class']) && $_GET['filter_class'] != '') $filterWhere .= " AND q.class_id = ".intval($_GET['filter_class']);
            if(isset($_GET['filter_subject']) && $_GET['filter_subject'] != '') $filterWhere .= " AND q.subject_id = ".intval($_GET['filter_subject']);
            
            $allQuestionsQ = mysqli_query($con, "SELECT q.*, s.sub_name, c.class as class_name FROM question q LEFT JOIN subject s ON q.subject_id = s.sub_id LEFT JOIN class c ON q.class_id = c.id WHERE q.school_id = $schoolId AND $filterWhere ORDER BY q.id DESC LIMIT 100");
            $qTotal = mysqli_num_rows($allQuestionsQ);
        ?>
        <div class="ng-card">
            <div class="ng-card-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                <h3><i class="fa fa-list"></i> All Questions (<?php echo $qTotal; ?>)</h3>
                <button type="submit" form="bulkDeleteQForm" class="ng-btn ng-btn-danger ng-btn-sm" onclick="return confirm('Delete all selected questions?');" style="display:none;" id="bulkDeleteBtn"><i class="fa fa-trash"></i> Delete Selected (<span id="selectedCount">0</span>)</button>
            </div>
            <div class="ng-card-body" style="padding:0;">
                <form method="post" id="bulkDeleteQForm">
                <table class="ng-table">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAllQ" onclick="toggleSelectAll(this, 'question_ids[]')"></th>
                            <th>#</th>
                            <th>Question</th>
                            <th>Class</th>
                            <th>Subject</th>
                            <th>Options</th>
                            <th>Answer</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sn=0; while($qRow = mysqli_fetch_assoc($allQuestionsQ)): $sn++; ?>
                        <tr>
                            <td><input type="checkbox" name="question_ids[]" value="<?php echo $qRow['id']; ?>" class="bulk-check" onchange="updateBulkCount('question_ids[]')"></td>
                            <td><?php echo $sn; ?></td>
                            <td style="max-width:300px; font-size:0.85rem;"><?php echo mb_strimwidth(strip_tags($qRow['question_desc']), 0, 80, '...'); ?></td>
                            <td><span class="ng-badge ng-badge-green"><?php echo $qRow['class_name'] ?: 'N/A'; ?></span></td>
                            <td><span class="ng-badge ng-badge-gold"><?php echo $qRow['sub_name'] ?: 'N/A'; ?></span></td>
                            <td style="font-size:0.8rem; color:var(--ng-text-light);">
                                A: <?php echo mb_strimwidth($qRow['option1'], 0, 20, '..'); ?><br>
                                B: <?php echo mb_strimwidth($qRow['option2'], 0, 20, '..'); ?><br>
                                C: <?php echo mb_strimwidth($qRow['option3'], 0, 20, '..'); ?><br>
                                D: <?php echo mb_strimwidth($qRow['option4'], 0, 20, '..'); ?>
                            </td>
                            <td style="font-weight:700; color:var(--ng-green); font-size:0.85rem;"><?php echo mb_strimwidth($qRow['true_answer'], 0, 25, '..'); ?></td>
                            <td>
                                <a href="?page=questions&delete_q=<?php echo $qRow['id']; ?><?php echo isset($_GET['filter_class']) ? '&filter_class='.$_GET['filter_class'] : ''; ?><?php echo isset($_GET['filter_subject']) ? '&filter_subject='.$_GET['filter_subject'] : ''; ?>" 
                                   class="ng-btn ng-btn-danger ng-btn-sm" title="Delete question">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if($qTotal == 0): ?>
                        <tr><td colspan="8" style="text-align:center; padding:30px; color:var(--ng-text-light);">No questions found. Upload some using Single or Bulk Upload.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <input type="hidden" name="bulk_delete_questions" value="1">
                </form>
            </div>
        </div>
        </div>

        <?php endif; ?>
    </main>
</div>

<script src="../assets/js/jquery-3.2.1.min.js"></script>
<script src="../assets/sweetalert.min.js"></script>
<script>
    function showSubject(val) {
        $.ajax({
            type: "POST",
            url: "../includes/subjects.php",
            data: 'classSubject=' + val,
            success: function(data) { $("#classSubject").html(data); }
        });
    }

    function showBulkSubject(val) {
        $.ajax({
            type: "POST",
            url: "../includes/subjects.php",
            data: 'classSubject=' + val,
            success: function(data) { $("#bulkClassSubject").html(data); }
        });
    }

    function showTab(tabName) {
        // Hide all panels
        document.getElementById('panel-single').style.display = 'none';
        document.getElementById('panel-bulk').style.display = 'none';
        document.getElementById('panel-manage').style.display = 'none';
        // Reset all tab buttons
        document.getElementById('tab-single').className = 'ng-btn ng-btn-outline';
        document.getElementById('tab-bulk').className = 'ng-btn ng-btn-outline';
        document.getElementById('tab-manage').className = 'ng-btn ng-btn-outline';
        // Show active
        document.getElementById('panel-' + tabName).style.display = 'block';
        document.getElementById('tab-' + tabName).className = 'ng-btn ng-btn-green';
    }

    // Auto-show manage tab if filter params exist
    <?php if(isset($_GET['filter_class']) || isset($_GET['filter_subject']) || isset($_GET['delete_q'])): ?>
        showTab('manage');
    <?php endif; ?>
    <?php if(isset($_GET['success']) && strpos($_GET['success'] ?? '', 'of') !== false): ?>
        showTab('bulk');
    <?php endif; ?>
    
    function logoutAdmin() {
        swal({
            title: "Logout?",
            text: "Are you sure you want to logout?",
            icon: "warning",
            buttons: true,
            dangerMode: true
        }).then(function(willLogout) {
            if(willLogout) { window.location = "../includes/adminLogout.php"; }
        });
    }
    // Bulk select/delete helpers
    function toggleSelectAll(el, name) {
        var checks = document.querySelectorAll('input[name="' + name + '"]');
        checks.forEach(function(c) { c.checked = el.checked; });
        updateBulkCount(name);
    }
    function updateBulkCount(name) {
        var checks = document.querySelectorAll('input[name="' + name + '"]:checked');
        var btn = document.getElementById('bulkDeleteBtn');
        var cnt = document.getElementById('selectedCount');
        if(btn) {
            if(checks.length > 0) { btn.style.display = 'inline-flex'; cnt.textContent = checks.length; }
            else { btn.style.display = 'none'; }
        }
    }
</script>
<?php include_once '../includes/live_chat_widget.php'; ?>
</body>
</html>