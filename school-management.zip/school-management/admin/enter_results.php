<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = '';

// Save results
if(isset($_POST['saveResults'])) {
    $classId = intval($_POST['class_id']);
    $subjectId = intval($_POST['subject_id']);
    $term = mysqli_real_escape_string($con, $_POST['term']);
    $session = mysqli_real_escape_string($con, $_POST['session']);

    if(isset($_POST['students'])) {
        foreach($_POST['students'] as $studentId => $scores) {
            $ca1 = intval($scores['ca1']);
            $ca2 = intval($scores['ca2']);
            $exam = intval($scores['exam']);
            $total = $ca1 + $ca2 + $exam;
            $grade = getGrade($total);
            $remark = getGradeRemark($grade);
            
            // Check if result exists
            $existing = mysqli_query($con, "SELECT id FROM term_results WHERE student_id=$studentId AND subject_id=$subjectId AND class_id=$classId AND term='$term' AND session='$session'");
            
            if(mysqli_num_rows($existing) > 0) {
                $r = mysqli_fetch_assoc($existing);
                mysqli_query($con, "UPDATE term_results SET ca1=$ca1, ca2=$ca2, ca3=0, exam_score=$exam, total=$total, grade='$grade', remark='$remark' WHERE id=".$r['id']);
            } else {
                mysqli_query($con, "INSERT INTO term_results (school_id, student_id, subject_id, class_id, term, session, ca1, ca2, ca3, exam_score, total, grade, remark) VALUES ($schoolId, $studentId, $subjectId, $classId, '$term', '$session', $ca1, $ca2, 0, $exam, $total, '$grade', '$remark')");
            }
        }
        $msg = 'Results saved successfully!';
    }
}

$selectedClass = isset($_GET['class_id']) ? intval($_GET['class_id']) : (isset($_POST['class_id']) ? intval($_POST['class_id']) : 0);
$selectedSubject = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : (isset($_POST['subject_id']) ? intval($_POST['subject_id']) : 0);
$selectedTerm = isset($_GET['term']) ? $_GET['term'] : (isset($_POST['term']) ? $_POST['term'] : $school['current_term']);
$selectedSession = isset($_GET['session']) ? $_GET['session'] : (isset($_POST['session']) ? $_POST['session'] : $school['current_session']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Results — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php" class="active"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-pencil-square-o"></i> Enter Term Results</h1></div>
        <?php if(!empty($msg)): ?><div class="ng-alert ng-alert-success"><i class="fa fa-check"></i> <?php echo $msg; ?></div><?php endif; ?>

        <!-- Filter Form -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-body">
                <form method="get" style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr auto; gap:12px; align-items:end;">
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Class</label>
                        <select name="class_id" class="ng-select" required>
                            <option value="">Select</option>
                            <?php $clsQ=mysqli_query($con,"SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c=mysqli_fetch_assoc($clsQ)): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo $c['id']==$selectedClass?'selected':''; ?>><?php echo $c['class']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Subject</label>
                        <select name="subject_id" class="ng-select" required>
                            <option value="">Select</option>
                            <?php $subQ=mysqli_query($con,"SELECT * FROM subject WHERE school_id = $schoolId ORDER BY sub_name"); while($s=mysqli_fetch_assoc($subQ)): ?>
                            <option value="<?php echo $s['sub_id']; ?>" <?php echo $s['sub_id']==$selectedSubject?'selected':''; ?>><?php echo $s['sub_name']; ?> (<?php echo getClassName($s['class_id']); ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Term</label>
                        <select name="term" class="ng-select">
                            <?php foreach(['1st Term','2nd Term','3rd Term'] as $t): ?>
                            <option value="<?php echo $t; ?>" <?php echo $t==$selectedTerm?'selected':''; ?>><?php echo $t; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Session</label>
                        <input type="text" name="session" class="ng-input" value="<?php echo $selectedSession; ?>">
                    </div>
                    <button type="submit" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-search"></i> Load</button>
                </form>
            </div>
        </div>

        <?php if($selectedClass > 0 && $selectedSubject > 0): ?>
        <!-- Spreadsheet Result Entry -->
        <div class="ng-card">
            <div class="ng-card-header">
                <h3>Enter Scores — <?php echo getSubjectName($selectedSubject); ?> (<?php echo getClassName($selectedClass); ?>)</h3>
            </div>
            <div class="ng-card-body result-entry-table" style="padding:0;">
                <form method="post">
                    <input type="hidden" name="class_id" value="<?php echo $selectedClass; ?>">
                    <input type="hidden" name="subject_id" value="<?php echo $selectedSubject; ?>">
                    <input type="hidden" name="term" value="<?php echo $selectedTerm; ?>">
                    <input type="hidden" name="session" value="<?php echo $selectedSession; ?>">
                    
                    <table class="ng-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student Name</th>
                                <th>Reg No.</th>
                                <th style="width:90px;">CA1 (20)</th>
                                <th style="width:90px;">CA2 (20)</th>
                                <th style="width:90px;">Exam (60)</th>
                                <th>Total</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $studQ = mysqli_query($con, "SELECT * FROM register WHERE department = '$selectedClass' AND school_id = $schoolId ORDER BY surname, otherNames");
                                $sn=0;
                                while($stu = mysqli_fetch_assoc($studQ)): $sn++;
                                    // Pre-fill existing results
                                    $existQ = mysqli_query($con, "SELECT * FROM term_results WHERE student_id=".$stu['id']." AND subject_id=$selectedSubject AND term='$selectedTerm' AND session='$selectedSession'");
                                    $exist = mysqli_fetch_assoc($existQ);
                            ?>
                            <tr>
                                <td><?php echo $sn; ?></td>
                                <td style="font-weight:600;"><?php echo $stu['surname'].' '.$stu['otherNames']; ?></td>
                                <td><span class="ng-badge ng-badge-green"><?php echo $stu['examNumber']; ?></span></td>
                                <td><input type="number" name="students[<?php echo $stu['id']; ?>][ca1]" min="0" max="20" value="<?php echo $exist?$exist['ca1']:0; ?>" onchange="calcRow(this)"></td>
                                <td><input type="number" name="students[<?php echo $stu['id']; ?>][ca2]" min="0" max="20" value="<?php echo $exist?$exist['ca2']:0; ?>" onchange="calcRow(this)"></td>
                                <td><input type="number" name="students[<?php echo $stu['id']; ?>][exam]" min="0" max="60" value="<?php echo $exist?$exist['exam_score']:0; ?>" onchange="calcRow(this)"></td>
                                <td class="auto-total"><?php echo $exist?$exist['total']:0; ?></td>
                                <td class="auto-grade"><?php echo $exist?$exist['grade']:'-'; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div style="padding:20px; text-align:center;">
                        <button type="submit" name="saveResults" class="ng-btn ng-btn-green ng-btn-lg">
                            <i class="fa fa-save"></i> Save All Results
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>

<script>
function calcRow(el) {
    var row = el.closest('tr');
    var inputs = row.querySelectorAll('input[type="number"]');
    var total = 0;
    inputs.forEach(function(inp) { total += parseInt(inp.value) || 0; });
    row.querySelector('.auto-total').textContent = total;
    
    // Grade
    var grade = '-';
    if(total >= 75) grade = 'A1';
    else if(total >= 70) grade = 'B2';
    else if(total >= 65) grade = 'B3';
    else if(total >= 60) grade = 'C4';
    else if(total >= 55) grade = 'C5';
    else if(total >= 50) grade = 'C6';
    else if(total >= 45) grade = 'D7';
    else if(total >= 40) grade = 'E8';
    else if(total > 0) grade = 'F9';
    row.querySelector('.auto-grade').textContent = grade;
}
</script>
</body>
</html>
