<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/smtp_config.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
$smtp = function_exists('getSmtpSettings') ? getSmtpSettings() : ['smtp_host'=>'','smtp_port'=>587,'smtp_username'=>'','smtp_password'=>'','smtp_encryption'=>'tls','smtp_from_email'=>'','smtp_from_name'=>''];

if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$successMsg = '';
$errorMsg = '';

// Handle logo upload
if(isset($_POST['updateSettings'])) {
    $schoolName = mysqli_real_escape_string($con, $_POST['school_name']);
    $schoolMotto = mysqli_real_escape_string($con, $_POST['school_motto']);
    $schoolAddress = mysqli_real_escape_string($con, $_POST['school_address']);
    $principalName = mysqli_real_escape_string($con, $_POST['principal_name']);
    $schoolEmail = mysqli_real_escape_string($con, $_POST['school_email']);
    $schoolPhone = mysqli_real_escape_string($con, $_POST['school_phone']);
    $currentTerm = mysqli_real_escape_string($con, $_POST['current_term']);
    $currentSession = mysqli_real_escape_string($con, $_POST['current_session']);
    $nextTermBegins = mysqli_real_escape_string($con, $_POST['next_term_begins']);
    $primaryColor = mysqli_real_escape_string($con, trim($_POST['primary_color'] ?? '#008751'));

    // Handle logo file upload
    $logoPath = $school['school_logo']; // Keep current if no new upload
    if(isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $fileName = $_FILES['school_logo']['name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        if(in_array($fileExt, $allowed)) {
            $newFileName = 'school_logo_' . time() . '.' . $fileExt;
            $uploadPath = '../images/' . $newFileName;
            
            // Delete old logo files (except default)
            foreach(glob('../images/school_logo_*') as $oldLogo) {
                @unlink($oldLogo);
            }
            
            if(move_uploaded_file($_FILES['school_logo']['tmp_name'], $uploadPath)) {
                $logoPath = 'images/' . $newFileName;
            } else {
                $errorMsg = 'Failed to upload logo file. Check directory permissions.';
            }
        } else {
            $errorMsg = 'Invalid file type. Allowed: JPG, PNG, GIF, WebP.';
        }
    }

    if(empty($errorMsg)) {
        $updateQ = mysqli_query($con, "UPDATE schools SET 
            school_name = '$schoolName',
            school_motto = '$schoolMotto',
            school_address = '$schoolAddress',
            school_logo = '$logoPath',
            principal_name = '$principalName',
            school_email = '$schoolEmail',
            school_phone = '$schoolPhone',
            current_term = '$currentTerm',
            current_session = '$currentSession',
            next_term_begins = '$nextTermBegins',
            primary_color = '$primaryColor'
            WHERE id = $schoolId
        ");
        
        if($updateQ) {
            $successMsg = 'School settings updated successfully!';
            $school = getSchoolSettings(); // Refresh
        } else {
            $errorMsg = 'Error updating settings: ' . mysqli_error($con);
        }
    }
}

// Save SMTP settings
if(isset($_POST['updateSmtp'])) {
    $smtpHost = mysqli_real_escape_string($con, trim($_POST['smtp_host']));
    $smtpPort = intval($_POST['smtp_port']);
    $smtpUser = mysqli_real_escape_string($con, trim($_POST['smtp_username']));
    $smtpPass = mysqli_real_escape_string($con, $_POST['smtp_password']);
    $smtpEnc = mysqli_real_escape_string($con, $_POST['smtp_encryption']);
    $smtpFromEmail = mysqli_real_escape_string($con, trim($_POST['smtp_from_email']));
    $smtpFromName = mysqli_real_escape_string($con, trim($_POST['smtp_from_name']));
    
    $q = mysqli_query($con, "UPDATE schools SET 
        smtp_host='$smtpHost', smtp_port=$smtpPort, smtp_username='$smtpUser', 
        smtp_password='$smtpPass', smtp_encryption='$smtpEnc',
        smtp_from_email='$smtpFromEmail', smtp_from_name='$smtpFromName' WHERE id=$schoolId");
    
    if($q) {
        $successMsg = 'SMTP settings updated successfully!';
        $smtp = getSmtpSettings();
    } else {
        $errorMsg = 'Error updating SMTP settings.';
    }
}

// Test SMTP
if(isset($_POST['testSmtp'])) {
    $testTo = mysqli_real_escape_string($con, trim($_POST['test_email']));
    if(!empty($testTo)) {
        $result = sendEmail($testTo, 'Test Recipient', 'SMTP Test — ' . $school['school_name'], 
            '<p>This is a test email from <strong>' . $school['school_name'] . '</strong>.</p><p>If you received this, your SMTP settings are configured correctly! ✅</p>');
        if($result['success']) {
            $successMsg = 'Test email sent successfully to ' . htmlspecialchars($testTo) . '!';
        } else {
            $errorMsg = $result['message'];
        }
    } else {
        $errorMsg = 'Please enter a test email address.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $school['school_name']; ?> — School Settings</title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>

<div class="admin-layout">
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="sidebar-header">
            <img src="../<?php echo $school['school_logo']; ?>" alt="Logo">
            <h3><?php echo $school['school_name']; ?></h3>
        </div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php" class="active"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>

    <main class="admin-content">
        <div class="admin-topbar">
            <h1><i class="fa fa-cog"></i> School Settings</h1>
        </div>

        <?php if(!empty($successMsg)): ?>
            <div class="ng-alert ng-alert-success"><i class="fa fa-check-circle"></i> <?php echo $successMsg; ?></div>
        <?php endif; ?>
        <?php if(!empty($errorMsg)): ?>
            <div class="ng-alert ng-alert-error"><i class="fa fa-exclamation-circle"></i> <?php echo $errorMsg; ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px;">
                <!-- School Identity -->
                <div class="ng-card">
                    <div class="ng-card-header"><h3>🏫 School Identity</h3></div>
                    <div class="ng-card-body">
                        <div class="ng-input-group">
                            <label>School Name</label>
                            <input type="text" name="school_name" class="ng-input" value="<?php echo $school['school_name']; ?>" required>
                        </div>
                        <div class="ng-input-group">
                            <label>School Motto</label>
                            <input type="text" name="school_motto" class="ng-input" value="<?php echo $school['school_motto']; ?>">
                        </div>
                        <div class="ng-input-group">
                            <label>School Address</label>
                            <textarea name="school_address" class="ng-input" rows="2"><?php echo $school['school_address']; ?></textarea>
                        </div>
                        <div class="ng-input-group">
                            <label>Principal's Name</label>
                            <input type="text" name="principal_name" class="ng-input" value="<?php echo $school['principal_name']; ?>">
                        </div>
                    </div>
                </div>

                <!-- Logo Upload -->
                <div class="ng-card">
                    <div class="ng-card-header"><h3>🖼️ School Logo</h3></div>
                    <div class="ng-card-body" style="text-align:center;">
                        <div style="margin-bottom:20px;">
                            <img src="../<?php echo $school['school_logo']; ?>" alt="Current Logo" 
                                 style="width:150px; height:150px; object-fit:contain; border:3px solid var(--ng-border); border-radius:var(--ng-radius); padding:10px; background:white;"
                                 id="logoPreview">
                        </div>
                        <p style="font-size:0.85rem; color:var(--ng-text-light); margin-bottom:12px;">Current school logo</p>
                        
                        <div class="ng-input-group">
                            <label>Upload New Logo</label>
                            <input type="file" name="school_logo" class="ng-input" accept="image/*" onchange="previewLogo(this)">
                        </div>
                        <p style="font-size:0.75rem; color:var(--ng-text-light);">Accepted formats: JPG, PNG, GIF, WebP. Recommended size: 200×200px.</p>
                    </div>
                </div>

                <!-- Dashboard Color -->
                <div class="ng-card">
                    <div class="ng-card-header"><h3>🎨 Dashboard Theme</h3></div>
                    <div class="ng-card-body" style="text-align:center;">
                        <p style="font-size:0.85rem; color:var(--ng-text-light); margin-bottom:16px;">Choose your school's dashboard color theme</p>
                        <div style="display:flex; gap:8px; justify-content:center; flex-wrap:wrap; margin-bottom:16px;">
                            <?php
                            $presetColors = ['#008751','#1a1a2e','#2563eb','#7c3aed','#dc2626','#ea580c','#0891b2','#059669','#4f46e5','#be185d'];
                            $currentColor = $school['primary_color'] ?? '#008751';
                            foreach($presetColors as $pc): ?>
                            <div onclick="selectColor('<?php echo $pc; ?>')" style="width:40px; height:40px; border-radius:50%; background:<?php echo $pc; ?>; cursor:pointer; border:3px solid <?php echo $currentColor==$pc?'#1a1a2e':'transparent'; ?>; transition:all 0.2s;" title="<?php echo $pc; ?>"></div>
                            <?php endforeach; ?>
                        </div>
                        <div class="ng-input-group" style="max-width:200px; margin:0 auto;">
                            <label>Custom Color</label>
                            <input type="color" name="primary_color" id="colorPicker" value="<?php echo $currentColor; ?>" style="width:100%; height:50px; border:none; border-radius:8px; cursor:pointer;">
                        </div>
                        <div id="colorPreview" style="margin-top:12px; padding:12px; border-radius:8px; color:white; font-weight:700; background:<?php echo $currentColor; ?>;">
                            Preview: Your Dashboard Theme
                        </div>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="ng-card">
                    <div class="ng-card-header"><h3>📞 Contact Information</h3></div>
                    <div class="ng-card-body">
                        <div class="ng-input-group">
                            <label>School Email</label>
                            <input type="email" name="school_email" class="ng-input" value="<?php echo $school['school_email']; ?>">
                        </div>
                        <div class="ng-input-group">
                            <label>School Phone</label>
                            <input type="text" name="school_phone" class="ng-input" value="<?php echo $school['school_phone']; ?>">
                        </div>
                    </div>
                </div>

                <!-- Academic Session -->
                <div class="ng-card">
                    <div class="ng-card-header"><h3>📅 Academic Session</h3></div>
                    <div class="ng-card-body">
                        <div class="ng-input-group">
                            <label>Current Term</label>
                            <select name="current_term" class="ng-select">
                                <option value="1st Term" <?php echo ($school['current_term'] == '1st Term') ? 'selected' : ''; ?>>1st Term</option>
                                <option value="2nd Term" <?php echo ($school['current_term'] == '2nd Term') ? 'selected' : ''; ?>>2nd Term</option>
                                <option value="3rd Term" <?php echo ($school['current_term'] == '3rd Term') ? 'selected' : ''; ?>>3rd Term</option>
                            </select>
                        </div>
                        <div class="ng-input-group">
                            <label>Current Session</label>
                            <input type="text" name="current_session" class="ng-input" value="<?php echo $school['current_session']; ?>" placeholder="e.g., 2025/2026">
                        </div>
                        <div class="ng-input-group">
                            <label>Next Term Begins</label>
                            <input type="text" name="next_term_begins" class="ng-input" value="<?php echo $school['next_term_begins']; ?>" placeholder="e.g., 6th January, 2026">
                        </div>
                    </div>
                </div>
            </div>

            <div style="text-align:center; margin-top:24px;">
                <button type="submit" name="updateSettings" class="ng-btn ng-btn-green ng-btn-lg" style="padding:16px 60px;">
                    <i class="fa fa-save"></i> Save All Settings
                </button>
            </div>
        </form>

        <!-- SMTP Configuration -->
        <div class="ng-card" style="margin-top:32px;">
            <div class="ng-card-header"><h3><i class="fa fa-envelope"></i> SMTP Email Configuration</h3></div>
            <div class="ng-card-body">
                <form method="POST">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                        <div class="ng-input-group">
                            <label>SMTP Host</label>
                            <input type="text" name="smtp_host" class="ng-input" value="<?php echo htmlspecialchars($smtp['smtp_host']); ?>" placeholder="e.g., smtp.gmail.com">
                        </div>
                        <div class="ng-input-group">
                            <label>SMTP Port</label>
                            <input type="number" name="smtp_port" class="ng-input" value="<?php echo $smtp['smtp_port']; ?>" placeholder="587">
                        </div>
                        <div class="ng-input-group">
                            <label>SMTP Username</label>
                            <input type="text" name="smtp_username" class="ng-input" value="<?php echo htmlspecialchars($smtp['smtp_username']); ?>" placeholder="your-email@gmail.com">
                        </div>
                        <div class="ng-input-group">
                            <label>SMTP Password / App Password</label>
                            <input type="password" name="smtp_password" class="ng-input" value="<?php echo htmlspecialchars($smtp['smtp_password']); ?>" placeholder="••••••••">
                        </div>
                        <div class="ng-input-group">
                            <label>Encryption</label>
                            <select name="smtp_encryption" class="ng-select">
                                <option value="tls" <?php echo $smtp['smtp_encryption']=='tls'?'selected':''; ?>>TLS (Recommended)</option>
                                <option value="ssl" <?php echo $smtp['smtp_encryption']=='ssl'?'selected':''; ?>>SSL</option>
                                <option value="none" <?php echo $smtp['smtp_encryption']=='none'?'selected':''; ?>>None</option>
                            </select>
                        </div>
                        <div class="ng-input-group">
                            <label>From Name</label>
                            <input type="text" name="smtp_from_name" class="ng-input" value="<?php echo htmlspecialchars($smtp['smtp_from_name']); ?>" placeholder="<?php echo $school['school_name']; ?>">
                        </div>
                        <div class="ng-input-group" style="grid-column:span 2;">
                            <label>From Email</label>
                            <input type="email" name="smtp_from_email" class="ng-input" value="<?php echo htmlspecialchars($smtp['smtp_from_email']); ?>" placeholder="noreply@yourschool.com">
                        </div>
                    </div>
                    <div style="display:flex; gap:12px; margin-top:16px;">
                        <button type="submit" name="updateSmtp" class="ng-btn ng-btn-green">
                            <i class="fa fa-save"></i> Save SMTP Settings
                        </button>
                    </div>
                </form>

                <!-- Test Email -->
                <hr style="margin:24px 0; border-color:var(--ng-border);">
                <h4 style="margin-bottom:12px;"><i class="fa fa-paper-plane"></i> Test SMTP Connection</h4>
                <form method="POST" style="display:flex; gap:12px; align-items:end;">
                    <div class="ng-input-group" style="margin-bottom:0; flex:1;">
                        <label>Send test email to</label>
                        <input type="email" name="test_email" class="ng-input" placeholder="recipient@example.com" required>
                    </div>
                    <button type="submit" name="testSmtp" class="ng-btn ng-btn-gold" style="height:52px;">
                        <i class="fa fa-paper-plane"></i> Send Test
                    </button>
                </form>
            </div>
        </div>
    </main>
</div>

<script>
function previewLogo(input) {
    if(input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('logoPreview').src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}
function selectColor(color) {
    document.getElementById('colorPicker').value = color;
    document.getElementById('colorPreview').style.background = color;
}
document.getElementById('colorPicker').addEventListener('input', function() {
    document.getElementById('colorPreview').style.background = this.value;
});
</script>
</body>
</html>
