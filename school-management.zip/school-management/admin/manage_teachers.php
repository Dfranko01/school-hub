<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = ''; $msgType = 'success';

// Add teacher
if(isset($_POST['addTeacher'])) {
    $name = mysqli_real_escape_string($con, $_POST['full_name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $staffId = mysqli_real_escape_string($con, $_POST['staff_id']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $qual = mysqli_real_escape_string($con, $_POST['qualification']);
    $username = mysqli_real_escape_string($con, trim($_POST['username']));
    $password = !empty($_POST['password']) ? sha1($_POST['password']) : '';
    
    if(!empty($username)) {
        $checkUser = mysqli_query($con, "SELECT id FROM teachers WHERE username = '$username' AND school_id = $schoolId");
        if(mysqli_num_rows($checkUser) > 0) { $msg = 'Username already exists!'; $msgType = 'error'; }
    }
    
    if($msgType !== 'error') {
         $q = mysqli_query($con, "INSERT INTO teachers (school_id, full_name, email, phone, staff_id, gender, qualification, username, password) VALUES ($schoolId, '$name', '$email', '$phone', '$staffId', '$gender', '$qual', '$username', '$password')");
        if($q) {
            $newTeacherId = mysqli_insert_id($con);
            if(isset($_POST['assigned_classes']) && is_array($_POST['assigned_classes'])) {
                foreach($_POST['assigned_classes'] as $classId) {
                    mysqli_query($con, "INSERT IGNORE INTO teacher_class_assignments (teacher_id, class_id) VALUES ($newTeacherId, " . intval($classId) . ")");
                }
            }
            $msg = 'Teacher added successfully!';
        } else { $msg = 'Error: ' . mysqli_error($con); $msgType = 'error'; }
    }
}

// Update teacher
if(isset($_POST['updateTeacher'])) {
    $id = intval($_POST['teacher_id']);
    $name = mysqli_real_escape_string($con, $_POST['edit_full_name']);
    $email = mysqli_real_escape_string($con, $_POST['edit_email']);
    $phone = mysqli_real_escape_string($con, $_POST['edit_phone']);
    $staffId = mysqli_real_escape_string($con, $_POST['edit_staff_id']);
    $gender = mysqli_real_escape_string($con, $_POST['edit_gender']);
    $qual = mysqli_real_escape_string($con, $_POST['edit_qualification']);
    $username = mysqli_real_escape_string($con, trim($_POST['edit_username']));
    $passwordUpdate = '';
    if(!empty($_POST['edit_password'])) { $passwordUpdate = ", password='" . sha1($_POST['edit_password']) . "'"; }
    
     mysqli_query($con, "UPDATE teachers SET full_name='$name', email='$email', phone='$phone', staff_id='$staffId', gender='$gender', qualification='$qual', username='$username' $passwordUpdate WHERE id=$id AND school_id=$schoolId");
    
    mysqli_query($con, "DELETE FROM teacher_class_assignments WHERE teacher_id = $id");
    if(isset($_POST['edit_assigned_classes']) && is_array($_POST['edit_assigned_classes'])) {
        foreach($_POST['edit_assigned_classes'] as $classId) {
            mysqli_query($con, "INSERT IGNORE INTO teacher_class_assignments (teacher_id, class_id) VALUES ($id, " . intval($classId) . ")");
        }
    }
    $msg = 'Teacher updated successfully!';
}

// Delete teacher
if(isset($_GET['delete'])) {
    $delId = intval($_GET['delete']);
    mysqli_query($con, "DELETE FROM teacher_class_assignments WHERE teacher_id = $delId");
    mysqli_query($con, "DELETE FROM teachers WHERE id = $delId AND school_id = $schoolId");
    header("Location: manage_teachers.php?msg=Teacher+removed"); exit;
}

// Bulk delete teachers
if(isset($_POST['bulk_delete_teachers']) && !empty($_POST['teacher_ids'])) {
    $ids = array_map('intval', $_POST['teacher_ids']);
    $idList = implode(',', $ids);
    mysqli_query($con, "DELETE FROM teacher_class_assignments WHERE teacher_id IN ($idList)");
    mysqli_query($con, "DELETE FROM teachers WHERE id IN ($idList) AND school_id = $schoolId");
    $count = count($ids);
    header("Location: manage_teachers.php?msg=" . urlencode("$count teacher(s) deleted successfully!")); exit;
}

$allClasses = [];
$clsQ = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id");
while($c = mysqli_fetch_assoc($clsQ)) { $allClasses[] = $c; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Teachers — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        .edit-modal-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; justify-content:center; align-items:center; }
        .edit-modal-overlay.active { display:flex; }
        .edit-modal { background:white; border-radius:var(--ng-radius); padding:32px; width:90%; max-width:650px; max-height:90vh; overflow-y:auto; box-shadow:0 8px 40px rgba(0,0,0,0.2); }
        .edit-modal h3 { font-family:'Outfit',sans-serif; color:var(--ng-green-dark); margin-bottom:20px; }
        .edit-modal .close-modal { float:right; background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--ng-text-light); }
        .class-checkboxes { display:flex; flex-wrap:wrap; gap:8px; padding:8px 0; }
        .class-checkboxes label { display:flex; align-items:center; gap:4px; padding:6px 12px; background:var(--ng-bg); border-radius:20px; font-size:0.82rem; cursor:pointer; border:1px solid var(--ng-border); transition:all 0.2s; }
        .class-checkboxes label:has(input:checked) { background:#dcfce7; border-color:var(--ng-green); color:var(--ng-green-dark); font-weight:600; }
        .class-checkboxes input[type="checkbox"] { accent-color:var(--ng-green); }
    </style>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php" class="active"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-users"></i> Manage Teachers</h1></div>

        <?php if(!empty($msg) || isset($_GET['msg'])): ?>
            <div class="ng-alert ng-alert-<?php echo $msgType; ?>"><i class="fa fa-check-circle"></i> <?php echo !empty($msg) ? $msg : htmlspecialchars($_GET['msg']); ?></div>
        <?php endif; ?>

        <div class="ng-card ng-mb-3">
            <div class="ng-card-header"><h3><i class="fa fa-user-plus"></i> Add New Teacher</h3></div>
            <div class="ng-card-body">
                <form method="post">
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
                        <div class="ng-input-group"><label>Full Name <span style="color:red;">*</span></label><input type="text" name="full_name" class="ng-input" required></div>
                        <div class="ng-input-group"><label>Email</label><input type="email" name="email" class="ng-input"></div>
                        <div class="ng-input-group"><label>Phone</label><input type="text" name="phone" class="ng-input"></div>
                        <div class="ng-input-group"><label>Staff ID</label><input type="text" name="staff_id" class="ng-input"></div>
                        <div class="ng-input-group"><label>Gender</label><select name="gender" class="ng-select"><option value="Male">Male</option><option value="Female">Female</option></select></div>
                        <div class="ng-input-group"><label>Qualification</label><input type="text" name="qualification" class="ng-input" placeholder="e.g. B.Ed Mathematics"></div>
                    </div>
                    <div style="margin-top:8px; padding:16px; background:#eff6ff; border-radius:8px; border:1px dashed #93c5fd;">
                        <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:8px;">🏫 Assign to Classes</label>
                        <div class="class-checkboxes">
                            <?php foreach($allClasses as $cls): ?>
                            <label><input type="checkbox" name="assigned_classes[]" value="<?php echo $cls['id']; ?>"> <?php echo $cls['class']; ?></label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-top:8px; padding:16px; background:#f0fdf4; border-radius:8px; border:1px dashed var(--ng-green-light);">
                        <div class="ng-input-group" style="margin-bottom:0;"><label>🔑 Login Username</label><input type="text" name="username" class="ng-input" placeholder="e.g. teacher.john"></div>
                        <div class="ng-input-group" style="margin-bottom:0;"><label>🔒 Login Password</label><input type="text" name="password" class="ng-input" placeholder="Set a password"></div>
                    </div>
                    <button type="submit" name="addTeacher" class="ng-btn ng-btn-green ng-mt-2"><i class="fa fa-plus"></i> Add Teacher</button>
                </form>
            </div>
        </div>

        <div class="ng-card">
            <div class="ng-card-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                <h3><i class="fa fa-list"></i> All Teachers</h3>
                <button type="submit" form="bulkDeleteTeachersForm" class="ng-btn ng-btn-danger ng-btn-sm" onclick="return confirm('Delete all selected teachers?');" style="display:none;" id="bulkDeleteBtn"><i class="fa fa-trash"></i> Delete Selected (<span id="selectedCount">0</span>)</button>
            </div>
            <div class="ng-card-body" style="padding:0;">
                <form method="post" id="bulkDeleteTeachersForm">
                <table class="ng-table">
                    <thead><tr><th><input type="checkbox" id="selectAllTeachers" onclick="toggleSelectAll(this, 'teacher_ids[]')"></th><th>#</th><th>Name</th><th>Staff ID</th><th>Username</th><th>Assigned Classes</th><th>Qualification</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php
                            $tchQ = mysqli_query($con, "SELECT * FROM teachers WHERE school_id = $schoolId ORDER BY full_name");
                            $sn=0; while($t = mysqli_fetch_assoc($tchQ)): $sn++;
                            $assignedQ = mysqli_query($con, "SELECT c.id, c.class FROM teacher_class_assignments tca JOIN class c ON tca.class_id = c.id WHERE tca.teacher_id = " . $t['id'] . " ORDER BY c.id");
                            $assignedClasses = []; $assignedIds = [];
                            while($a = mysqli_fetch_assoc($assignedQ)) { $assignedClasses[] = $a['class']; $assignedIds[] = $a['id']; }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="teacher_ids[]" value="<?php echo $t['id']; ?>" class="bulk-check" onchange="updateBulkCount('teacher_ids[]')"></td>
                            <td><?php echo $sn; ?></td>
                            <td style="font-weight:600;"><?php echo $t['full_name']; ?></td>
                            <td><span class="ng-badge ng-badge-green"><?php echo $t['staff_id']; ?></span></td>
                            <td><?php echo $t['username'] ? '<code>'.$t['username'].'</code>' : '<span style="color:#aaa;">—</span>'; ?></td>
                            <td>
                                <?php if(count($assignedClasses) > 0): ?>
                                    <?php foreach($assignedClasses as $ac): ?><span class="ng-badge ng-badge-gold" style="margin:2px;"><?php echo $ac; ?></span><?php endforeach; ?>
                                <?php else: ?><span style="color:#aaa; font-size:0.82rem;">No class assigned</span><?php endif; ?>
                            </td>
                            <td style="font-size:0.85rem;"><?php echo $t['qualification']; ?></td>
                            <td style="white-space:nowrap;">
                                <button type="button" class="ng-btn ng-btn-outline ng-btn-sm edit-teacher-btn"
                                    data-id="<?php echo $t['id']; ?>"
                                    data-fullname="<?php echo htmlspecialchars($t['full_name']); ?>"
                                    data-email="<?php echo htmlspecialchars($t['email'] ?? ''); ?>"
                                    data-phone="<?php echo htmlspecialchars($t['phone'] ?? ''); ?>"
                                    data-staffid="<?php echo htmlspecialchars($t['staff_id'] ?? ''); ?>"
                                    data-gender="<?php echo $t['gender'] ?? 'Male'; ?>"
                                    data-qualification="<?php echo htmlspecialchars($t['qualification'] ?? ''); ?>"
                                    data-username="<?php echo htmlspecialchars($t['username'] ?? ''); ?>"
                                    data-classids="<?php echo implode(',', $assignedIds); ?>">
                                    <i class="fa fa-pencil"></i>
                                </button>
                                <a href="?delete=<?php echo $t['id']; ?>" 
                                   class="ng-btn ng-btn-danger ng-btn-sm" title="Delete teacher">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <input type="hidden" name="bulk_delete_teachers" value="1">
                </form>
            </div>
        </div>
    </main>
</div>

<!-- Edit Teacher Modal -->
<div class="edit-modal-overlay" id="editTeacherModal">
    <div class="edit-modal">
        <button class="close-modal" onclick="document.getElementById('editTeacherModal').classList.remove('active')">&times;</button>
        <h3><i class="fa fa-pencil"></i> Edit Teacher</h3>
        <form method="post">
            <input type="hidden" name="teacher_id" id="edit_teacher_id">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div class="ng-input-group"><label>Full Name</label><input type="text" name="edit_full_name" id="edit_full_name" class="ng-input" required></div>
                <div class="ng-input-group"><label>Email</label><input type="email" name="edit_email" id="edit_email" class="ng-input"></div>
                <div class="ng-input-group"><label>Phone</label><input type="text" name="edit_phone" id="edit_phone" class="ng-input"></div>
                <div class="ng-input-group"><label>Staff ID</label><input type="text" name="edit_staff_id" id="edit_staff_id" class="ng-input"></div>
                <div class="ng-input-group"><label>Gender</label><select name="edit_gender" id="edit_gender" class="ng-select"><option value="Male">Male</option><option value="Female">Female</option></select></div>
                <div class="ng-input-group"><label>Qualification</label><input type="text" name="edit_qualification" id="edit_qualification" class="ng-input"></div>
            </div>
            <div style="margin-top:8px; padding:16px; background:#eff6ff; border-radius:8px; border:1px dashed #93c5fd;">
                <label style="font-weight:600; font-size:0.9rem; display:block; margin-bottom:8px;">🏫 Assigned Classes</label>
                <div class="class-checkboxes" id="edit_class_checkboxes">
                    <?php foreach($allClasses as $cls): ?>
                    <label><input type="checkbox" name="edit_assigned_classes[]" value="<?php echo $cls['id']; ?>" data-class-id="<?php echo $cls['id']; ?>"> <?php echo $cls['class']; ?></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-top:8px; padding:16px; background:#f0fdf4; border-radius:8px; border:1px dashed var(--ng-green-light);">
                <div class="ng-input-group" style="margin-bottom:0;"><label>🔑 Username</label><input type="text" name="edit_username" id="edit_username" class="ng-input"></div>
                <div class="ng-input-group" style="margin-bottom:0;"><label>🔒 New Password <small>(blank = keep)</small></label><input type="text" name="edit_password" class="ng-input" placeholder="Leave blank to keep current"></div>
            </div>
            <div style="display:flex; gap:12px; margin-top:16px;">
                <button type="submit" name="updateTeacher" class="ng-btn ng-btn-green"><i class="fa fa-save"></i> Save Changes</button>
                <button type="button" class="ng-btn ng-btn-outline" onclick="document.getElementById('editTeacherModal').classList.remove('active')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
// Edit teacher buttons
document.querySelectorAll('.edit-teacher-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('edit_teacher_id').value = this.dataset.id;
        document.getElementById('edit_full_name').value = this.dataset.fullname;
        document.getElementById('edit_email').value = this.dataset.email;
        document.getElementById('edit_phone').value = this.dataset.phone;
        document.getElementById('edit_staff_id').value = this.dataset.staffid;
        document.getElementById('edit_gender').value = this.dataset.gender;
        document.getElementById('edit_qualification').value = this.dataset.qualification;
        document.getElementById('edit_username').value = this.dataset.username;
        
        var assignedIds = this.dataset.classids ? this.dataset.classids.split(',').map(Number) : [];
        document.querySelectorAll('#edit_class_checkboxes input[type="checkbox"]').forEach(function(cb) {
            cb.checked = assignedIds.indexOf(parseInt(cb.dataset.classId)) !== -1;
        });
        
        document.getElementById('editTeacherModal').classList.add('active');
    });
});

// Modal close on overlay
document.getElementById('editTeacherModal').addEventListener('click', function(e) {
    if(e.target === this) this.classList.remove('active');
});
</script>
<script>
function toggleSelectAll(el, name) {
    var checks = document.querySelectorAll('input[name="' + name + '"]');
    checks.forEach(function(c) { c.checked = el.checked; });
    updateBulkCount(name);
}
function updateBulkCount(name) {
    var checks = document.querySelectorAll('input[name="' + name + '"]:checked');
    var btn = document.getElementById('bulkDeleteBtn');
    var cnt = document.getElementById('selectedCount');
    if(checks.length > 0) { btn.style.display = 'inline-flex'; cnt.textContent = checks.length; }
    else { btn.style.display = 'none'; }
}
</script>
<?php include_once '../includes/live_chat_widget.php'; ?>
</body>
</html>
