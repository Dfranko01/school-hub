<?php
session_start();
include_once '../includes/config.php';

// Get school context from slug
$schoolSlug = isset($_GET['school']) ? trim($_GET['school']) : (isset($_SESSION['school_slug']) ? $_SESSION['school_slug'] : '');
if(!empty($schoolSlug)) {
    $schoolData = getSchoolBySlug($schoolSlug);
    if($schoolData) {
        $_SESSION['school_id'] = $schoolData['id'];
        $_SESSION['school_slug'] = $schoolData['school_slug'];
    }
}

$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();

if($schoolId == 0) {
    echo '<script>alert("No school selected. Please access via your school portal."); window.location="../../";</script>';
    exit;
}

// Handle login
$errorMessage = '';
if(isset($_POST['adminLogin'])){
    $username = addslashes($_POST['username']);   
    $passwordHash = sha1($_POST['password']);
    $passwordPlain = addslashes($_POST['password']);
    $query = mysqli_query($con, "SELECT * FROM admin WHERE Username = '$username' AND (Password = '$passwordHash' OR Password = '$passwordPlain') AND school_id = $schoolId");
    $rows = mysqli_num_rows($query);
    $fetch = mysqli_fetch_array($query);
    
    if(empty($_POST['username']) || empty($_POST['password'])) {
        $errorMessage = "All fields are required!";
    } elseif($rows === 1) {
        $_SESSION['id'] = $fetch['id'];
        $_SESSION['username'] = $fetch['Username'];
        $_SESSION['admin_school_id'] = $schoolId;
        header("Location: question_portal.php");
        exit;
    } else {
        $errorMessage = "Invalid login credentials!";
    }
}

if(isset($_SESSION['id']) && isset($_SESSION['username']) && isset($_SESSION['admin_school_id']) && $_SESSION['admin_school_id'] == $schoolId) {
    header("Location: question_portal.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $school['school_name']; ?> — Admin Login</title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="login-page">
    <div class="login-brand">
        <img src="../<?php echo $school['school_logo']; ?>" alt="School Logo" class="school-logo">
        <h1><?php echo $school['school_name']; ?></h1>
        <p class="motto">"<?php echo $school['school_motto']; ?>"</p>
        <p class="address">Administration Portal</p>
    </div>
    <div class="login-form-section">
        <div class="login-form-container">
            <h2>Admin Panel 🔐</h2>
            <p class="subtitle">Login to manage your school portal</p>
            <?php if(!empty($errorMessage)): ?>
                <div class="ng-alert ng-alert-error"><i class="fa fa-exclamation-circle"></i> <?php echo $errorMessage; ?></div>
            <?php endif; ?>
            <div class="login-card">
                <form method="post">
                    <div class="ng-input-group"><label><i class="fa fa-user"></i> Username</label><input type="text" name="username" class="ng-input" placeholder="Enter your username" autofocus required></div>
                    <div class="ng-input-group"><label><i class="fa fa-lock"></i> Password</label><input type="password" name="password" class="ng-input" placeholder="Enter your password" required></div>
                    <button type="submit" name="adminLogin" class="ng-btn ng-btn-green ng-btn-lg ng-btn-block"><i class="fa fa-sign-in"></i> LOGIN</button>
                </form>
            </div>
            <p style="text-align:center; margin-top:20px; font-size:0.8rem; color:var(--ng-text-light);">
                <a href="../portal.php?school=<?php echo $school['school_slug']; ?>" style="color:var(--ng-text-light);"><i class="fa fa-arrow-left"></i> Back to Student Portal</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>