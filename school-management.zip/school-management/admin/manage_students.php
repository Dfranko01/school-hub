<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';

$schoolId = getCurrentSchoolId();
$school = getSchoolSettings();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = ''; $msgType = 'success';

// Auto-fix columns
$requiredCols = [
    'email' => "ALTER TABLE `register` ADD COLUMN `email` varchar(300) NOT NULL DEFAULT '' AFTER `phoneNumber`",
    'current_class' => "ALTER TABLE `register` ADD COLUMN `current_class` varchar(100) NOT NULL DEFAULT '' AFTER `department`",
    'admission_no' => "ALTER TABLE `register` ADD COLUMN `admission_no` varchar(100) NOT NULL DEFAULT '' AFTER `examNumber`"
];
$existingCols = [];
$colCheck = mysqli_query($con, "SHOW COLUMNS FROM register");
if($colCheck) { while($col = mysqli_fetch_assoc($colCheck)) { $existingCols[] = $col['Field']; } }
foreach($requiredCols as $colName => $alterSql) {
    if(!in_array($colName, $existingCols)) { mysqli_query($con, $alterSql); }
}

// Add student
if(isset($_POST['addStudent'])) {
    $surname = mysqli_real_escape_string($con, trim($_POST['surname']));
    $otherNames = mysqli_real_escape_string($con, trim($_POST['otherNames']));
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $phone = mysqli_real_escape_string($con, trim($_POST['phone']));
    $dob = mysqli_real_escape_string($con, trim($_POST['dob']));
    $classId = mysqli_real_escape_string($con, $_POST['class_id']);
    $admissionNo = mysqli_real_escape_string($con, trim($_POST['admission_no']));
    $examNumber = mysqli_real_escape_string($con, trim($_POST['exam_number']));
    // Auto-generate if empty
    if(empty($examNumber)) {
        $examNumber = generateExamNumber($schoolId);
    }
    $email = mysqli_real_escape_string($con, trim($_POST['email']));
    $passport = 'images/avatar.png';
    
    if(isset($_FILES['passport']) && $_FILES['passport']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','gif','webp'];
        $ext = strtolower(pathinfo($_FILES['passport']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $newName = 'student_' . time() . '_' . rand(100,999) . '.' . $ext;
            $uploadPath = '../images/students/' . $newName;
            if(!is_dir('../images/students')) mkdir('../images/students', 0777, true);
            if(move_uploaded_file($_FILES['passport']['tmp_name'], $uploadPath)) {
                $passport = 'images/students/' . $newName;
            }
        }
    }
    
    $check = mysqli_query($con, "SELECT id FROM register WHERE examNumber = '$examNumber' AND school_id = $schoolId");
    if(mysqli_num_rows($check) > 0) {
        $msg = 'A student with this Registration Number already exists!';
        $msgType = 'error';
    } else {
        $q = mysqli_query($con, "INSERT INTO register (school_id, surname, otherNames, gender, phoneNumber, email, DateOfBirth, department, current_class, level, passport, examNumber, admission_no, subject1, subject2, subject3, subject4, subject5, subject6, subject7, subject8, subject9) 
            VALUES ($schoolId, '$surname', '$otherNames', '$gender', '$phone', '$email', '$dob', '$classId', '$classId', '$classId', '$passport', '$examNumber', '$admissionNo', '', '', '', '', '', '', '', '', '')");
        if($q) {
            $msg = "$surname $otherNames registered successfully!";
        } else {
            $msg = 'Error adding student: ' . mysqli_error($con);
            $msgType = 'error';
        }
    }
}

// Update student
if(isset($_POST['updateStudent'])) {
    $id = intval($_POST['student_id']);
    $surname = mysqli_real_escape_string($con, trim($_POST['edit_surname']));
    $otherNames = mysqli_real_escape_string($con, trim($_POST['edit_otherNames']));
    $gender = mysqli_real_escape_string($con, $_POST['edit_gender']);
    $phone = mysqli_real_escape_string($con, trim($_POST['edit_phone']));
    $dob = mysqli_real_escape_string($con, trim($_POST['edit_dob']));
    $classId = mysqli_real_escape_string($con, $_POST['edit_class_id']);
    $admissionNo = mysqli_real_escape_string($con, trim($_POST['edit_admission_no']));
    $examNumber = mysqli_real_escape_string($con, trim($_POST['edit_exam_number']));
    $email = mysqli_real_escape_string($con, trim($_POST['edit_email']));
    
    $passportUpdate = '';
    if(isset($_FILES['edit_passport']) && $_FILES['edit_passport']['error'] == 0) {
        $allowed = ['jpg','jpeg','png','gif','webp'];
        $ext = strtolower(pathinfo($_FILES['edit_passport']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $newName = 'student_' . time() . '_' . rand(100,999) . '.' . $ext;
            $uploadPath = '../images/students/' . $newName;
            if(!is_dir('../images/students')) mkdir('../images/students', 0777, true);
            if(move_uploaded_file($_FILES['edit_passport']['tmp_name'], $uploadPath)) {
                $passportUpdate = ", passport='images/students/$newName'";
            }
        }
    }
    
    $q = mysqli_query($con, "UPDATE register SET surname='$surname', otherNames='$otherNames', gender='$gender', phoneNumber='$phone', email='$email', DateOfBirth='$dob', department='$classId', current_class='$classId', level='$classId', examNumber='$examNumber', admission_no='$admissionNo' $passportUpdate WHERE id=$id AND school_id=$schoolId");
    $msg = $q ? 'Student updated successfully!' : 'Error: ' . mysqli_error($con);
}

// Delete student
if(isset($_GET['delete_student'])) {
    $sid = intval($_GET['delete_student']);
    mysqli_query($con, "DELETE FROM register WHERE id = $sid AND school_id = $schoolId");
    header("Location: manage_students.php?msg=" . urlencode('Student deleted successfully!'));
    exit;
}

// Bulk delete students
if(isset($_POST['bulk_delete_students']) && !empty($_POST['student_ids'])) {
    $ids = array_map('intval', $_POST['student_ids']);
    $idList = implode(',', $ids);
    mysqli_query($con, "DELETE FROM register WHERE id IN ($idList) AND school_id = $schoolId");
    $count = mysqli_affected_rows($con);
    header("Location: manage_students.php?msg=" . urlencode("$count student(s) deleted successfully!"));
    exit;
}

// Bulk CSV Upload
if(isset($_POST['bulk_upload_csv']) && isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === 0) {
    $ext = strtolower(pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION));
    if($ext !== 'csv') {
        $msg = 'Please upload a valid CSV file.'; $msgType = 'error';
    } else {
        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        $header = fgetcsv($handle); // read header row
        $added = 0; $skipped = 0; $errors = [];
        while(($row = fgetcsv($handle)) !== false) {
            if(count($row) < 3) continue; // need at least surname, othernames, gender
            $surname = mysqli_real_escape_string($con, trim($row[0]));
            $otherNames = mysqli_real_escape_string($con, trim($row[1]));
            $gender = mysqli_real_escape_string($con, trim($row[2]));
            $classId = isset($row[3]) ? mysqli_real_escape_string($con, trim($row[3])) : '';
            $phone = isset($row[4]) ? mysqli_real_escape_string($con, trim($row[4])) : '';
            $email = isset($row[5]) ? mysqli_real_escape_string($con, trim($row[5])) : '';
            $dob = isset($row[6]) ? mysqli_real_escape_string($con, trim($row[6])) : '';
            $admissionNo = isset($row[7]) ? mysqli_real_escape_string($con, trim($row[7])) : '';
            
            if(empty($surname) || empty($otherNames)) { $skipped++; continue; }
            
            // Resolve class by name if not numeric
            if(!empty($classId) && !is_numeric($classId)) {
                $clsLookup = mysqli_query($con, "SELECT id FROM class WHERE class = '" . $classId . "' AND school_id = $schoolId LIMIT 1");
                $classId = ($clsLookup && mysqli_num_rows($clsLookup) > 0) ? mysqli_fetch_assoc($clsLookup)['id'] : '';
            }
            
            $examNumber = generateExamNumber($schoolId);
            $q = mysqli_query($con, "INSERT INTO register (school_id, surname, otherNames, gender, phoneNumber, email, DateOfBirth, department, current_class, level, passport, examNumber, admission_no, subject1, subject2, subject3, subject4, subject5, subject6, subject7, subject8, subject9) 
                VALUES ($schoolId, '$surname', '$otherNames', '$gender', '$phone', '$email', '$dob', '$classId', '$classId', '$classId', 'images/avatar.png', '$examNumber', '$admissionNo', '', '', '', '', '', '', '', '', '')");
            if($q) { $added++; } else { $skipped++; }
        }
        fclose($handle);
        $msg = "Bulk upload complete: $added student(s) added, $skipped skipped.";
        $msgType = $added > 0 ? 'success' : 'error';
    }
}

$filterClass = isset($_GET['filter_class']) ? intval($_GET['filter_class']) : '';
$filterWhere = $filterClass ? "WHERE r.department = '$filterClass' AND r.school_id = $schoolId" : "WHERE r.school_id = $schoolId";
$studentsQ = mysqli_query($con, "SELECT r.*, c.class as class_name FROM register r LEFT JOIN class c ON r.department = c.id $filterWhere ORDER BY r.surname, r.otherNames");
$totalStudents = mysqli_num_rows($studentsQ);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        .edit-modal-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; justify-content:center; align-items:center; }
        .edit-modal-overlay.active { display:flex; }
        .edit-modal { background:white; border-radius:var(--ng-radius); padding:32px; width:90%; max-width:650px; max-height:90vh; overflow-y:auto; box-shadow:0 8px 40px rgba(0,0,0,0.2); }
        .edit-modal h3 { font-family:'Outfit',sans-serif; color:var(--ng-green-dark); margin-bottom:20px; }
        .edit-modal .close-modal { float:right; background:none; border:none; font-size:1.5rem; cursor:pointer; color:var(--ng-text-light); }
    </style>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php" class="active"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-users"></i> Manage Students</h1></div>

        <?php if(!empty($msg) || isset($_GET['msg'])): ?>
            <div class="ng-alert ng-alert-<?php echo $msgType; ?>"><i class="fa fa-<?php echo $msgType=='success'?'check':'exclamation'; ?>-circle"></i> <?php echo !empty($msg) ? $msg : htmlspecialchars($_GET['msg']); ?></div>
        <?php endif; ?>

        <!-- Add Student Form -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-header"><h3><i class="fa fa-user-plus"></i> Register New Student</h3></div>
            <div class="ng-card-body">
                <form method="post" enctype="multipart/form-data">
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
                        <div class="ng-input-group"><label>Surname <span style="color:red;">*</span></label><input type="text" name="surname" class="ng-input" placeholder="e.g. Okonkwo" required></div>
                        <div class="ng-input-group"><label>Other Names <span style="color:red;">*</span></label><input type="text" name="otherNames" class="ng-input" placeholder="e.g. Chidinma Grace" required></div>
                        <div class="ng-input-group"><label>Gender <span style="color:red;">*</span></label><select name="gender" class="ng-select" required><option value="">Select</option><option value="Male">Male</option><option value="Female">Female</option></select></div>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
                        <div class="ng-input-group"><label>Registration/Exam Number <span style="color:green; font-size:0.8rem;">Auto-generated</span></label><input type="text" name="exam_number" class="ng-input" value="<?php echo generateExamNumber($schoolId); ?>" readonly style="background:#f0fdf4; font-weight:700; letter-spacing:1px;"></div>
                        <div class="ng-input-group"><label>Admission Number</label><input type="text" name="admission_no" class="ng-input" placeholder="e.g. ADM/001"></div>
                        <div class="ng-input-group">
                            <label>Class <span style="color:red;">*</span></label>
                            <select name="class_id" class="ng-select" required>
                                <option value="">Select Class</option>
                                <?php $clsQ = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c = mysqli_fetch_assoc($clsQ)): ?>
                                <option value="<?php echo $c['id']; ?>"><?php echo $c['class']; ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
                        <div class="ng-input-group"><label>Phone Number</label><input type="text" name="phone" class="ng-input" placeholder="+234 80x xxx xxxx"></div>
                        <div class="ng-input-group"><label>Email Address</label><input type="email" name="email" class="ng-input" placeholder="student@email.com"></div>
                        <div class="ng-input-group"><label>Date of Birth</label><input type="date" name="dob" class="ng-input"></div>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr; gap:16px;">
                        <div class="ng-input-group"><label>Passport Photo</label><input type="file" name="passport" class="ng-input" accept="image/*"></div>
                    </div>
                    <button type="submit" name="addStudent" class="ng-btn ng-btn-green ng-btn-lg ng-btn-block"><i class="fa fa-user-plus"></i> Register Student</button>
                </form>
            </div>
        </div>

        <!-- Bulk CSV Upload -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-header"><h3><i class="fa fa-upload"></i> Bulk Upload Students (CSV)</h3></div>
            <div class="ng-card-body">
                <form method="post" enctype="multipart/form-data" style="display:flex; gap:12px; align-items:end; flex-wrap:wrap;">
                    <div class="ng-input-group" style="margin-bottom:0; flex:1; min-width:200px;">
                        <label>CSV File <small style="color:#9ca3af;">(<a href="#" onclick="downloadCSVTemplate(); return false;" style="color:var(--ng-green);">Download Template</a>)</small></label>
                        <input type="file" name="csv_file" class="ng-input" accept=".csv" required>
                    </div>
                    <button type="submit" name="bulk_upload_csv" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-cloud-upload"></i> Upload CSV</button>
                </form>
                <div style="background:#f0fdf4; border:1px solid #22c55e; border-radius:8px; padding:10px 14px; margin-top:12px; font-size:0.78rem; line-height:1.6;">
                    <strong>CSV Columns:</strong> Surname, Other Names, Gender, Class, Phone, Email, Date of Birth (YYYY-MM-DD), Admission No<br>
                    <strong>Note:</strong> Registration numbers are auto-generated. Class can be the class name (e.g. "JSS 1") or class ID.
                </div>
            </div>
        </div>

        <!-- Filter -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-body" style="padding:12px 16px;">
                <form method="get" style="display:flex; gap:12px; align-items:end;">
                    <div class="ng-input-group" style="margin-bottom:0; flex:1;">
                        <label>Filter by Class</label>
                        <select name="filter_class" class="ng-select">
                            <option value="">All Classes</option>
                            <?php $clsQ2 = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c2 = mysqli_fetch_assoc($clsQ2)): ?>
                            <option value="<?php echo $c2['id']; ?>" <?php echo $filterClass==$c2['id']?'selected':''; ?>><?php echo $c2['class']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-filter"></i> Filter</button>
                </form>
            </div>
        </div>

        <!-- Students List -->
        <div class="ng-card">
            <div class="ng-card-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                <h3><i class="fa fa-list"></i> All Students (<?php echo $totalStudents; ?>)</h3>
                <button type="submit" form="bulkDeleteForm" class="ng-btn ng-btn-danger ng-btn-sm" onclick="return confirm('Delete all selected students?');" style="display:none;" id="bulkDeleteBtn"><i class="fa fa-trash"></i> Delete Selected (<span id="selectedCount">0</span>)</button>
            </div>
            <div class="ng-card-body" style="padding:0;">
                <form method="post" id="bulkDeleteForm">
                <table class="ng-table">
                    <thead><tr><th><input type="checkbox" id="selectAllStudents" onclick="toggleSelectAll(this, 'student_ids[]')"></th><th>#</th><th>Photo</th><th>Name</th><th>Reg. Number</th><th>Gender</th><th>Class</th><th>Phone</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php $sn=0; while($stu = mysqli_fetch_assoc($studentsQ)): $sn++; ?>
                        <tr>
                            <td><input type="checkbox" name="student_ids[]" value="<?php echo $stu['id']; ?>" class="bulk-check" onchange="updateBulkCount('student_ids[]')"></td>
                            <td><?php echo $sn; ?></td>
                            <td><img src="../<?php echo $stu['passport'] ?: 'images/avatar.png'; ?>" alt="Photo" style="width:36px; height:36px; border-radius:50%; object-fit:cover; border:2px solid var(--ng-green-light);"></td>
                            <td style="font-weight:600;"><?php echo $stu['surname'] . ' ' . $stu['otherNames']; ?></td>
                            <td><code style="font-size:0.85rem;"><?php echo $stu['examNumber']; ?></code></td>
                            <td><?php echo $stu['gender']; ?></td>
                            <td><span class="ng-badge ng-badge-green"><?php echo $stu['class_name'] ?: 'N/A'; ?></span></td>
                            <td style="font-size:0.85rem;"><?php echo $stu['phoneNumber']; ?></td>
                            <td style="white-space:nowrap;">
                                <button type="button" class="ng-btn ng-btn-outline ng-btn-sm edit-student-btn"
                                    data-id="<?php echo $stu['id']; ?>" data-surname="<?php echo htmlspecialchars($stu['surname']); ?>"
                                    data-othernames="<?php echo htmlspecialchars($stu['otherNames']); ?>" data-gender="<?php echo $stu['gender']; ?>"
                                    data-examnumber="<?php echo htmlspecialchars($stu['examNumber']); ?>" data-admissionno="<?php echo htmlspecialchars($stu['admission_no'] ?? ''); ?>"
                                    data-department="<?php echo $stu['department']; ?>" data-phone="<?php echo htmlspecialchars($stu['phoneNumber']); ?>"
                                    data-email="<?php echo htmlspecialchars($stu['email'] ?? ''); ?>" data-dob="<?php echo $stu['DateOfBirth']; ?>">
                                    <i class="fa fa-pencil"></i>
                                </button>
                                <a href="?delete_student=<?php echo $stu['id']; ?><?php echo $filterClass ? '&filter_class='.$filterClass : ''; ?>" class="ng-btn ng-btn-danger ng-btn-sm" title="Delete" onclick="return confirm('Delete this student?');"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if($totalStudents == 0): ?>
                        <tr><td colspan="9" style="text-align:center; padding:30px; color:var(--ng-text-light);">No students found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <input type="hidden" name="bulk_delete_students" value="1">
                </form>
            </div>
        </div>
    </main>
</div>

<!-- Edit Modal -->
<div class="edit-modal-overlay" id="editStudentModal">
    <div class="edit-modal">
        <button class="close-modal" onclick="document.getElementById('editStudentModal').classList.remove('active')">&times;</button>
        <h3><i class="fa fa-pencil"></i> Edit Student</h3>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="student_id" id="edit_student_id">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div class="ng-input-group"><label>Surname</label><input type="text" name="edit_surname" id="edit_surname" class="ng-input" required></div>
                <div class="ng-input-group"><label>Other Names</label><input type="text" name="edit_otherNames" id="edit_otherNames" class="ng-input" required></div>
                <div class="ng-input-group"><label>Gender</label><select name="edit_gender" id="edit_gender" class="ng-select"><option value="Male">Male</option><option value="Female">Female</option></select></div>
                <div class="ng-input-group"><label>Reg/Exam Number</label><input type="text" name="edit_exam_number" id="edit_exam_number" class="ng-input" required></div>
                <div class="ng-input-group"><label>Admission Number</label><input type="text" name="edit_admission_no" id="edit_admission_no" class="ng-input"></div>
                <div class="ng-input-group">
                    <label>Class</label>
                    <select name="edit_class_id" id="edit_class_id" class="ng-select">
                        <?php $clsQ3 = mysqli_query($con, "SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c3 = mysqli_fetch_assoc($clsQ3)): ?>
                        <option value="<?php echo $c3['id']; ?>"><?php echo $c3['class']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="ng-input-group"><label>Phone</label><input type="text" name="edit_phone" id="edit_phone" class="ng-input"></div>
                <div class="ng-input-group"><label>Email</label><input type="email" name="edit_email" id="edit_email" class="ng-input"></div>
                <div class="ng-input-group"><label>Date of Birth</label><input type="date" name="edit_dob" id="edit_dob" class="ng-input"></div>
                <div class="ng-input-group" style="grid-column:1/-1;"><label>Update Photo (optional)</label><input type="file" name="edit_passport" class="ng-input" accept="image/*"></div>
            </div>
            <div style="display:flex; gap:12px; margin-top:16px;">
                <button type="submit" name="updateStudent" class="ng-btn ng-btn-green"><i class="fa fa-save"></i> Save</button>
                <button type="button" class="ng-btn ng-btn-outline" onclick="document.getElementById('editStudentModal').classList.remove('active')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
document.querySelectorAll('.edit-student-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('edit_student_id').value = this.dataset.id;
        document.getElementById('edit_surname').value = this.dataset.surname;
        document.getElementById('edit_otherNames').value = this.dataset.othernames;
        document.getElementById('edit_gender').value = this.dataset.gender;
        document.getElementById('edit_exam_number').value = this.dataset.examnumber;
        document.getElementById('edit_admission_no').value = this.dataset.admissionno;
        document.getElementById('edit_class_id').value = this.dataset.department;
        document.getElementById('edit_phone').value = this.dataset.phone;
        document.getElementById('edit_email').value = this.dataset.email || '';
        document.getElementById('edit_dob').value = this.dataset.dob;
        document.getElementById('editStudentModal').classList.add('active');
    });
});
document.getElementById('editStudentModal').addEventListener('click', function(e) { if(e.target === this) this.classList.remove('active'); });
</script>
<script>
// Bulk select/delete helpers
function toggleSelectAll(el, name) {
    var checks = document.querySelectorAll('input[name="' + name + '"]');
    checks.forEach(function(c) { c.checked = el.checked; });
    updateBulkCount(name);
}
function updateBulkCount(name) {
    var checks = document.querySelectorAll('input[name="' + name + '"]:checked');
    var btn = document.getElementById('bulkDeleteBtn');
    var cnt = document.getElementById('selectedCount');
    if(checks.length > 0) { btn.style.display = 'inline-flex'; cnt.textContent = checks.length; }
    else { btn.style.display = 'none'; }
}
function downloadCSVTemplate() {
    var csv = 'Surname,Other Names,Gender,Class,Phone,Email,Date of Birth,Admission No\n';
    csv += 'Okonkwo,Chidinma Grace,Female,JSS 1,08012345678,student@email.com,2010-05-15,ADM/001\n';
    csv += 'Adebayo,Segun Michael,Male,JSS 2,08098765432,,2009-03-22,ADM/002\n';
    var blob = new Blob([csv], { type: 'text/csv' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'student_upload_template.csv';
    a.click();
}
</script>
<?php include_once '../includes/live_chat_widget.php'; ?>
</body>
</html>
