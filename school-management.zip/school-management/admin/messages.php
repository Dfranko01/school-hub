<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
include_once '../includes/smtp_config.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

// Auto-fix: ensure messages table has required columns
$msgCols = [];
$colQ = mysqli_query($con, "SHOW COLUMNS FROM messages");
if($colQ) { while($c = mysqli_fetch_assoc($colQ)) { $msgCols[] = $c['Field']; } }
if(!in_array('sender_type', $msgCols)) { mysqli_query($con, "ALTER TABLE messages ADD COLUMN sender_type VARCHAR(20) NOT NULL DEFAULT 'student' AFTER school_id"); }
if(!in_array('student_id', $msgCols)) { mysqli_query($con, "ALTER TABLE messages ADD COLUMN student_id INT(11) NOT NULL DEFAULT 0 AFTER sender_type"); }
if(!in_array('admin_id', $msgCols)) { mysqli_query($con, "ALTER TABLE messages ADD COLUMN admin_id INT(11) NOT NULL DEFAULT 0 AFTER student_id"); }
if(!in_array('is_read', $msgCols)) { mysqli_query($con, "ALTER TABLE messages ADD COLUMN is_read TINYINT(1) NOT NULL DEFAULT 0"); }

$msg = ''; $msgType = 'success';

// Reply to message
if(isset($_POST['replyMessage'])) {
    $studentId = intval($_POST['reply_student_id']);
    $replyText = mysqli_real_escape_string($con, trim($_POST['reply_text']));
    $replySubject = mysqli_real_escape_string($con, trim($_POST['reply_subject']));
    
    if(!empty($replyText)) {
        $adminId = intval($_SESSION['admin_id'] ?? 1);
        mysqli_query($con, "INSERT INTO messages (school_id, student_id, admin_id, sender_type, subject, message) 
            VALUES ($schoolId, $studentId, $adminId, 'admin', '$replySubject', '$replyText')");
        
        // Also send email notification to student if they have email
        $stuQ = mysqli_query($con, "SELECT surname, otherNames, email FROM register WHERE id = $studentId AND school_id = $schoolId");
        if($stu = mysqli_fetch_assoc($stuQ)) {
            if(!empty($stu['email'])) {
                sendEmail($stu['email'], $stu['surname'].' '.$stu['otherNames'], 
                    'Reply: ' . $replySubject . ' — ' . $school['school_name'],
                    '<p><strong>The school has replied to your message:</strong></p><p>' . nl2br(htmlspecialchars($replyText)) . '</p>'
                );
            }
        }
        $msg = "Reply sent successfully!";
    }
}

// Delete message 
if(isset($_GET['delete_msg'])) {
    $msgId = intval($_GET['delete_msg']);
    mysqli_query($con, "DELETE FROM messages WHERE id = $msgId AND school_id = $schoolId");
    header("Location: messages.php?msg=" . urlencode("Message deleted."));
    exit;
}

// View thread
$viewStudent = isset($_GET['view']) ? intval($_GET['view']) : 0;

// Mark as read
if($viewStudent) {
    mysqli_query($con, "UPDATE messages SET is_read = 1 WHERE student_id = $viewStudent AND sender_type = 'student' AND school_id = $schoolId");
}

// Unread count
$unreadQ = mysqli_query($con, "SELECT COUNT(*) as c FROM messages WHERE sender_type='student' AND is_read=0 AND school_id=$schoolId");
$totalUnread = mysqli_fetch_assoc($unreadQ)['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
    <style>
        .msg-list { list-style:none; padding:0; margin:0; }
        .msg-item { padding:16px 20px; border-bottom:1px solid var(--ng-border); display:flex; gap:16px; align-items:flex-start; cursor:pointer; transition:background 0.2s; }
        .msg-item:hover { background:#f0fdf4; }
        .msg-item.unread { background:#f8faf9; border-left:3px solid var(--ng-green); }
        .msg-avatar { width:42px; height:42px; border-radius:50%; background:var(--ng-green-light); display:flex; align-items:center; justify-content:center; font-weight:700; color:var(--ng-green-dark); font-size:1rem; flex-shrink:0; }
        .msg-meta { flex:1; }
        .msg-name { font-weight:600; font-size:0.95rem; }
        .msg-subject { font-size:0.85rem; color:var(--ng-text); margin-top:2px; }
        .msg-preview { font-size:0.8rem; color:var(--ng-text-light); margin-top:4px; }
        .msg-time { font-size:0.75rem; color:var(--ng-text-light); white-space:nowrap; }
        .chat-bubble { padding:14px 18px; border-radius:16px; margin-bottom:12px; max-width:80%; font-size:0.9rem; line-height:1.6; }
        .chat-student { background:#f0f9ff; border:1px solid #bae6fd; margin-right:auto; border-bottom-left-radius:4px; }
        .chat-admin { background:#f0fdf4; border:1px solid #bbf7d0; margin-left:auto; border-bottom-right-radius:4px; }
        .chat-sender { font-weight:600; font-size:0.8rem; margin-bottom:4px; }
        .chat-time { font-size:0.72rem; color:var(--ng-text-light); margin-top:6px; }
    </style>
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php" class="active"><span class="nav-icon">💬</span> Messages <?php if($totalUnread > 0) echo '<span class="ng-badge ng-badge-red" style="margin-left:4px;font-size:0.7rem;">'.$totalUnread.'</span>'; ?></a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar">
            <h1><i class="fa fa-comments"></i> Messages <?php if($totalUnread > 0): ?><span class="ng-badge ng-badge-red"><?php echo $totalUnread; ?> unread</span><?php endif; ?></h1>
        </div>

        <?php if(!empty($msg) || isset($_GET['msg'])): ?>
            <div class="ng-alert ng-alert-<?php echo $msgType; ?>"><i class="fa fa-check-circle"></i> <?php echo !empty($msg) ? $msg : htmlspecialchars($_GET['msg']); ?></div>
        <?php endif; ?>

<?php if($viewStudent): ?>
        <?php
        // Get student info
        $stuQ = mysqli_query($con, "SELECT * FROM register WHERE id = $viewStudent AND school_id = $schoolId");
        $student = mysqli_fetch_assoc($stuQ);
        // Get all messages in thread
        $threadQ = mysqli_query($con, "SELECT * FROM messages WHERE student_id = $viewStudent ORDER BY created_at ASC");
        // Get the subject from first message
        $firstMsg = mysqli_query($con, "SELECT subject FROM messages WHERE student_id = $viewStudent ORDER BY id ASC LIMIT 1");
        $threadSubject = ($fm = mysqli_fetch_assoc($firstMsg)) ? $fm['subject'] : 'Conversation';
        ?>
        <a href="messages.php" class="ng-btn ng-btn-outline ng-mb-3" style="display:inline-block;">
            <i class="fa fa-arrow-left"></i> Back to Inbox
        </a>
        
        <div class="ng-card ng-mb-3">
            <div class="ng-card-header">
                <h3><i class="fa fa-user"></i> <?php echo $student ? $student['surname'].' '.$student['otherNames'] : 'Unknown Student'; ?></h3>
                <span class="ng-badge ng-badge-green"><?php echo $student ? $student['examNumber'] : ''; ?></span>
            </div>
            <div class="ng-card-body" style="max-height:500px; overflow-y:auto; padding:20px;">
                <?php while($m = mysqli_fetch_assoc($threadQ)): ?>
                <div class="chat-bubble <?php echo $m['sender_type'] == 'student' ? 'chat-student' : 'chat-admin'; ?>">
                    <div class="chat-sender">
                        <?php echo $m['sender_type'] == 'student' ? '👤 ' . htmlspecialchars($m['student_name'] ?: ($student['surname'].' '.$student['otherNames'])) : '🏫 Admin'; ?>
                    </div>
                    <?php if(!empty($m['subject'])): ?>
                    <div style="font-weight:600; font-size:0.85rem; margin-bottom:6px; color:var(--ng-green-dark);">
                        📌 <?php echo htmlspecialchars($m['subject']); ?>
                    </div>
                    <?php endif; ?>
                    <div><?php echo nl2br(htmlspecialchars($m['message'])); ?></div>
                    <div class="chat-time"><?php echo date('M d, Y \a\t h:i A', strtotime($m['created_at'])); ?></div>
                </div>
                <?php endwhile; ?>
            </div>
            <div class="ng-card-footer">
                <form method="POST" style="display:flex; gap:12px; align-items:end; width:100%;">
                    <input type="hidden" name="reply_student_id" value="<?php echo $viewStudent; ?>">
                    <input type="hidden" name="reply_subject" value="<?php echo htmlspecialchars($threadSubject); ?>">
                    <div class="ng-input-group" style="margin-bottom:0; flex:1;">
                        <textarea name="reply_text" class="ng-input" rows="2" placeholder="Type your reply..." required style="resize:none;"></textarea>
                    </div>
                    <button type="submit" name="replyMessage" class="ng-btn ng-btn-green" style="height:60px; padding:0 24px;">
                        <i class="fa fa-paper-plane"></i> Reply
                    </button>
                </form>
            </div>
        </div>

<?php else: ?>
        <!-- Inbox -->
        <div class="ng-card">
            <div class="ng-card-header"><h3><i class="fa fa-inbox"></i> Student Messages</h3></div>
            <div class="ng-card-body" style="padding:0;">
                <ul class="msg-list">
                    <?php
                    // Get unique conversations (grouped by student)
                    $convQ = mysqli_query($con, "
                        SELECT m.student_id, m.student_name, m.student_reg, m.subject,
                            MAX(m.created_at) as last_msg_time,
                            SUM(CASE WHEN m.sender_type='student' AND m.is_read=0 THEN 1 ELSE 0 END) as unread_count,
                            (SELECT message FROM messages m2 WHERE m2.student_id = m.student_id ORDER BY m2.id DESC LIMIT 1) as last_message
                        FROM messages m
                        WHERE m.school_id = $schoolId
                        GROUP BY m.student_id
                        ORDER BY last_msg_time DESC
                    ");
                    $hasMessages = false;
                    while($conv = mysqli_fetch_assoc($convQ)): $hasMessages = true;
                        $initials = strtoupper(substr($conv['student_name'], 0, 1));
                    ?>
                    <a href="messages.php?view=<?php echo $conv['student_id']; ?>" style="text-decoration:none; color:inherit;">
                        <li class="msg-item <?php echo $conv['unread_count'] > 0 ? 'unread' : ''; ?>">
                            <div class="msg-avatar"><?php echo $initials; ?></div>
                            <div class="msg-meta">
                                <div class="msg-name">
                                    <?php echo htmlspecialchars($conv['student_name']); ?>
                                    <?php if($conv['unread_count'] > 0): ?>
                                    <span class="ng-badge ng-badge-red" style="font-size:0.65rem; margin-left:6px;"><?php echo $conv['unread_count']; ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="msg-subject"><?php echo htmlspecialchars($conv['subject']); ?></div>
                                <div class="msg-preview"><?php echo htmlspecialchars(mb_strimwidth($conv['last_message'], 0, 80, '...')); ?></div>
                            </div>
                            <div class="msg-time"><?php echo date('M d, H:i', strtotime($conv['last_msg_time'])); ?></div>
                        </li>
                    </a>
                    <?php endwhile; ?>
                    <?php if(!$hasMessages): ?>
                    <li style="padding:40px; text-align:center; color:var(--ng-text-light);">
                        <i class="fa fa-inbox" style="font-size:2rem; display:block; margin-bottom:12px;"></i>
                        No messages yet. Students can send messages from the login page chat widget.
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
<?php endif; ?>
    </main>
</div>
</body>
</html>
