<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

$msg = '';
if(isset($_POST['addClass'])) {
    $className = mysqli_real_escape_string($con, $_POST['class_name']);
    $sortName = mysqli_real_escape_string($con, $_POST['sort_name']);
    $q = mysqli_query($con, "INSERT INTO class (school_id, class, sortname) VALUES ($schoolId, '$className', '$sortName')");
    $msg = $q ? 'Class added!' : 'Error: '.mysqli_error($con);
}
if(isset($_GET['delete'])) {
    mysqli_query($con, "DELETE FROM class WHERE id = ".intval($_GET['delete'])." AND school_id = $schoolId");
    header("Location: manage_classes.php?msg=Deleted"); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Classes — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php" class="active"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-building"></i> Manage Classes</h1></div>
        <?php if(!empty($msg)||isset($_GET['msg'])): ?><div class="ng-alert ng-alert-success"><i class="fa fa-check"></i> <?php echo !empty($msg)?$msg:$_GET['msg']; ?></div><?php endif; ?>

        <div class="ng-card ng-mb-3">
            <div class="ng-card-header"><h3>Add New Class</h3></div>
            <div class="ng-card-body">
                <form method="post">
                    <div style="display:grid; grid-template-columns:1fr 1fr auto; gap:12px; align-items:end;">
                        <div class="ng-input-group" style="margin-bottom:0;"><label>Class Name</label><input type="text" name="class_name" class="ng-input" placeholder="e.g. JSS 1A" required></div>
                        <div class="ng-input-group" style="margin-bottom:0;"><label>Short Name</label><input type="text" name="sort_name" class="ng-input" placeholder="e.g. JS1A"></div>
                        <button type="submit" name="addClass" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-plus"></i> Add</button>
                    </div>
                </form>
            </div>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(250px,1fr)); gap:20px;">
            <?php
                $clsQ = mysqli_query($con, "SELECT c.*, (SELECT COUNT(*) FROM register WHERE department = c.id AND school_id = $schoolId) as student_count, (SELECT COUNT(*) FROM subject WHERE class_id = c.id AND school_id = $schoolId) as subject_count FROM class c WHERE c.school_id = $schoolId ORDER BY c.id");
                while($c = mysqli_fetch_assoc($clsQ)):
            ?>
            <div class="ng-card">
                <div class="ng-card-body" style="text-align:center;">
                    <div style="width:64px; height:64px; border-radius:16px; background:linear-gradient(135deg, rgba(0,135,81,0.1), rgba(0,135,81,0.05)); display:flex; align-items:center; justify-content:center; margin:0 auto 12px; font-size:1.8rem;">🏫</div>
                    <h3 style="font-size:1.2rem; margin-bottom:4px;"><?php echo $c['class']; ?></h3>
                    <p style="color:var(--ng-text-light); font-size:0.85rem;"><?php echo $c['sortname']; ?></p>
                    <div style="display:flex; justify-content:center; gap:16px; margin-top:16px;">
                        <div>
                            <div style="font-weight:800; color:var(--ng-green); font-size:1.3rem;"><?php echo $c['student_count']; ?></div>
                            <div style="font-size:0.75rem; color:var(--ng-text-light);">Students</div>
                        </div>
                        <div>
                            <div style="font-weight:800; color:var(--ng-gold); font-size:1.3rem;"><?php echo $c['subject_count']; ?></div>
                            <div style="font-size:0.75rem; color:var(--ng-text-light);">Subjects</div>
                        </div>
                    </div>
                </div>
                <div class="ng-card-footer" style="text-align:center;">
                    <a href="?delete=<?php echo $c['id']; ?>" class="ng-btn ng-btn-danger ng-btn-sm" title="Delete">
                        <i class="fa fa-trash"></i> Delete
                    </a>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </main>
</div>
</body>
</html>
