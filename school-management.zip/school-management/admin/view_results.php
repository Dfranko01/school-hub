<?php
session_start();
include_once '../includes/config.php';
include_once '../includes/functions.php';
$school = getSchoolSettings();
$schoolId = getCurrentSchoolId();
if(!isset($_SESSION['username']) || $schoolId == 0) { header("Location: index.php"); exit; }

// Auto-create student_fees table
mysqli_query($con, "CREATE TABLE IF NOT EXISTS student_fees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    term VARCHAR(20) NOT NULL,
    session VARCHAR(20) NOT NULL,
    next_term_fees DECIMAL(12,2) DEFAULT 0,
    ca_fees DECIMAL(12,2) DEFAULT 0,
    outstanding_fees DECIMAL(12,2) DEFAULT 0,
    school_id INT DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_student_term (student_id, term, session)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Add school_id column if missing
mysqli_query($con, "ALTER TABLE student_fees ADD COLUMN IF NOT EXISTS school_id INT DEFAULT 0");

$selectedClass = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
$selectedTerm = isset($_GET['term']) ? $_GET['term'] : $school['current_term'];
$selectedSession = isset($_GET['session']) ? $_GET['session'] : $school['current_session'];

$successMsg = '';

// Bulk save fees
if(isset($_POST['saveBulkFees'])) {
    $bulkTerm = mysqli_real_escape_string($con, $_POST['bulk_term']);
    $bulkSession = mysqli_real_escape_string($con, $_POST['bulk_session']);
    
    if(isset($_POST['fees']) && is_array($_POST['fees'])) {
        foreach($_POST['fees'] as $stuId => $feeData) {
            $stuId = intval($stuId);
            $ntf = floatval(str_replace(',', '', $feeData['next_term_fees']));
            $caf = floatval(str_replace(',', '', $feeData['ca_fees']));
            $osf = floatval(str_replace(',', '', $feeData['outstanding_fees']));
            
            $existing = mysqli_query($con, "SELECT id FROM student_fees WHERE student_id = $stuId AND term = '$bulkTerm' AND session = '$bulkSession'");
            if(mysqli_num_rows($existing) > 0) {
                mysqli_query($con, "UPDATE student_fees SET next_term_fees = $ntf, ca_fees = $caf, outstanding_fees = $osf, school_id = $schoolId WHERE student_id = $stuId AND term = '$bulkTerm' AND session = '$bulkSession'");
            } else {
                mysqli_query($con, "INSERT INTO student_fees (student_id, term, session, next_term_fees, ca_fees, outstanding_fees, school_id) VALUES ($stuId, '$bulkTerm', '$bulkSession', $ntf, $caf, $osf, $schoolId)");
            }
        }
    }
    $successMsg = 'All fees saved successfully!';
    $selectedClass = intval($_POST['return_class_id']);
    $selectedTerm = $bulkTerm;
    $selectedSession = $bulkSession;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Results — <?php echo $school['school_name']; ?></title>
    <link rel="shortcut icon" href="../<?php echo $school['school_logo']; ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../css/nigerian-cbt.css">
    <?php if(!empty($school['primary_color'])): ?>
    <style>:root { --ng-green: <?php echo $school['primary_color']; ?>; --ng-green-dark: <?php echo $school['primary_color']; ?>; }</style>
    <?php endif; ?>
    <link rel="stylesheet" href="../assets/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php include_once '../includes/mobile_menu.php'; ?>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="sidebar-header"><img src="../<?php echo $school['school_logo']; ?>" alt="Logo"><h3><?php echo $school['school_name']; ?></h3></div>
        <ul class="sidebar-nav">
            <li><a href="question_portal.php"><span class="nav-icon">📊</span> Dashboard</a></li>
            <li><a href="question_portal.php?page=questions"><span class="nav-icon">📝</span> Question Bank</a></li>
            <li><a href="manage_students.php"><span class="nav-icon">👨‍🎓</span> Manage Students</a></li>
            <li><a href="manage_subjects.php"><span class="nav-icon">📚</span> Manage Subjects</a></li>
            <li><a href="manage_teachers.php"><span class="nav-icon">👩‍🏫</span> Manage Teachers</a></li>
            <li><a href="manage_classes.php"><span class="nav-icon">🏫</span> Manage Classes</a></li>
            <li><a href="manage_cbt.php"><span class="nav-icon">💻</span> CBT Results</a></li>
            <li><a href="enter_results.php"><span class="nav-icon">📊</span> Enter Results</a></li>
            <li><a href="view_results.php" class="active"><span class="nav-icon">📋</span> View Results</a></li>
            <li><a href="send_email.php"><span class="nav-icon">📧</span> Send Email</a></li>
            <li><a href="messages.php"><span class="nav-icon">💬</span> Messages</a></li>
            <li><a href="manage_pins.php"><span class="nav-icon">🔑</span> Result PINs</a></li>
            <li><a href="manage_cbt_pins.php"><span class="nav-icon">💳</span> CBT PINs</a></li>
            <li><a href="purchase_pins.php"><span class="nav-icon">🛒</span> Purchase PINs</a></li>
            <li><a href="school_settings.php"><span class="nav-icon">⚙️</span> School Settings</a></li>
            <li><a href="admin_settings.php"><span class="nav-icon">👤</span> Admin Account</a></li>
            <li><a href="../includes/adminLogout.php"><span class="nav-icon">🚪</span> Logout</a></li>
        </ul>
    </aside>
    <main class="admin-content">
        <div class="admin-topbar"><h1><i class="fa fa-bar-chart"></i> View & Print Results</h1></div>

        <?php if(!empty($successMsg)): ?>
            <div class="ng-alert ng-alert-success"><i class="fa fa-check-circle"></i> <?php echo $successMsg; ?></div>
        <?php endif; ?>

        <!-- Filter -->
        <div class="ng-card ng-mb-3">
            <div class="ng-card-body">
                <form method="get" style="display:grid; grid-template-columns:1fr 1fr 1fr auto; gap:12px; align-items:end;">
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Class</label>
                        <select name="class_id" class="ng-select" required>
                            <option value="">Select Class</option>
                            <?php $clsQ=mysqli_query($con,"SELECT * FROM class WHERE school_id = $schoolId ORDER BY id"); while($c=mysqli_fetch_assoc($clsQ)): ?>
                            <option value="<?php echo $c['id']; ?>" <?php echo $c['id']==$selectedClass?'selected':''; ?>><?php echo $c['class']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Term</label>
                        <select name="term" class="ng-select">
                            <?php foreach(['1st Term','2nd Term','3rd Term'] as $t): ?>
                            <option value="<?php echo $t; ?>" <?php echo $t==$selectedTerm?'selected':''; ?>><?php echo $t; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="ng-input-group" style="margin-bottom:0;">
                        <label>Session</label>
                        <input type="text" name="session" class="ng-input" value="<?php echo $selectedSession; ?>">
                    </div>
                    <button type="submit" class="ng-btn ng-btn-green" style="height:52px;"><i class="fa fa-search"></i> View</button>
                </form>
            </div>
        </div>

        <?php if($selectedClass > 0): ?>
        <div class="ng-card">
            <div class="ng-card-header" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                <h3><?php echo getClassName($selectedClass); ?> — <?php echo $selectedTerm; ?> (<?php echo $selectedSession; ?>)</h3>
                <button type="button" class="ng-btn ng-btn-gold ng-btn-sm" onclick="toggleFeesMode()">
                    <i class="fa fa-money"></i> <span id="feesToggleText">Manage Fees</span>
                </button>
            </div>
            <div class="ng-card-body" style="padding:0; overflow-x:auto;">
                <form method="post" id="bulkFeesForm">
                    <input type="hidden" name="bulk_term" value="<?php echo htmlspecialchars($selectedTerm); ?>">
                    <input type="hidden" name="bulk_session" value="<?php echo htmlspecialchars($selectedSession); ?>">
                    <input type="hidden" name="return_class_id" value="<?php echo $selectedClass; ?>">
                    
                <table class="ng-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student Name</th>
                            <th>Reg No.</th>
                            <th>Subjects</th>
                            <th>Average</th>
                            <th>Position</th>
                            <th class="fees-col" style="display:none;">Next Term (₦)</th>
                            <th class="fees-col" style="display:none;">CA Fees (₦)</th>
                            <th class="fees-col" style="display:none;">Outstanding (₦)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $studsQ = mysqli_query($con, "
                                SELECT r.id, r.surname, r.otherNames, r.examNumber,
                                    COUNT(tr.id) as sub_count,
                                    SUM(tr.total) as total_score,
                                    AVG(tr.total) as avg_score
                                FROM register r
                                LEFT JOIN term_results tr ON r.id = tr.student_id AND tr.class_id = '$selectedClass' AND tr.term = '$selectedTerm' AND tr.session = '$selectedSession'
                                WHERE r.department = '$selectedClass' AND r.school_id = $schoolId
                                GROUP BY r.id
                                ORDER BY avg_score DESC, r.surname
                            ");
                            $sn=0; $pos=0; $lastAvg=-1;
                            while($stu = mysqli_fetch_assoc($studsQ)): $sn++;
                                $avg = $stu['avg_score'] ? round($stu['avg_score'], 1) : 0;
                                if($avg != $lastAvg) { $pos = $sn; $lastAvg = $avg; }
                                
                                $safeTerm = mysqli_real_escape_string($con, $selectedTerm);
                                $safeSession = mysqli_real_escape_string($con, $selectedSession);
                                $feeQ = mysqli_query($con, "SELECT * FROM student_fees WHERE student_id = {$stu['id']} AND term = '$safeTerm' AND session = '$safeSession'");
                                $fee = ($feeQ && mysqli_num_rows($feeQ) > 0) ? mysqli_fetch_assoc($feeQ) : ['next_term_fees' => '', 'ca_fees' => '', 'outstanding_fees' => ''];
                        ?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td style="font-weight:600;"><?php echo $stu['surname'].' '.$stu['otherNames']; ?></td>
                            <td><span class="ng-badge ng-badge-green"><?php echo $stu['examNumber']; ?></span></td>
                            <td><?php echo $stu['sub_count']; ?></td>
                            <td>
                                <span class="ng-badge <?php echo $avg>=50?'ng-badge-green':'ng-badge-red'; ?>">
                                    <?php echo $avg; ?>%
                                </span>
                            </td>
                            <td><?php echo addOrdinalSuffix($pos); ?></td>
                            <td class="fees-col" style="display:none;">
                                <input type="text" name="fees[<?php echo $stu['id']; ?>][next_term_fees]" 
                                       class="ng-input" style="width:100px; padding:4px 6px; font-size:0.8rem;" 
                                       value="<?php echo $fee['next_term_fees'] > 0 ? number_format($fee['next_term_fees']) : ''; ?>" placeholder="0">
                            </td>
                            <td class="fees-col" style="display:none;">
                                <input type="text" name="fees[<?php echo $stu['id']; ?>][ca_fees]" 
                                       class="ng-input" style="width:100px; padding:4px 6px; font-size:0.8rem;" 
                                       value="<?php echo $fee['ca_fees'] > 0 ? number_format($fee['ca_fees']) : ''; ?>" placeholder="0">
                            </td>
                            <td class="fees-col" style="display:none;">
                                <input type="text" name="fees[<?php echo $stu['id']; ?>][outstanding_fees]" 
                                       class="ng-input" style="width:100px; padding:4px 6px; font-size:0.8rem; color:#dc2626;" 
                                       value="<?php echo $fee['outstanding_fees'] > 0 ? number_format($fee['outstanding_fees']) : ''; ?>" placeholder="0">
                            </td>
                            <td>
                                <a href="../view_report_card.php?sid=<?php echo $stu['id']; ?>&term=<?php echo urlencode($selectedTerm); ?>&session=<?php echo urlencode($selectedSession); ?>" 
                                   class="ng-btn ng-btn-green ng-btn-sm" target="_blank">
                                    <i class="fa fa-print"></i> Report Card
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                
                <div class="fees-col" style="display:none; padding:16px; text-align:center; border-top:2px solid var(--ng-border);">
                    <button type="submit" name="saveBulkFees" class="ng-btn ng-btn-green ng-btn-lg" style="padding:14px 50px;">
                        <i class="fa fa-save"></i> Save All Fees
                    </button>
                    <p style="margin-top:8px; font-size:0.8rem; color:var(--ng-text-light);">All fee amounts are in Nigerian Naira (₦).</p>
                </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>

<script>
var feesVisible = false;
function toggleFeesMode() {
    feesVisible = !feesVisible;
    document.querySelectorAll('.fees-col').forEach(function(el) {
        el.style.display = feesVisible ? '' : 'none';
    });
    document.getElementById('feesToggleText').textContent = feesVisible ? 'Hide Fees' : 'Manage Fees';
}
</script>
</body>
</html>
