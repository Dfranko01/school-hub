<?php 
	include('../include/config.php');
	if (isset($_POST['user']) && isset($_POST['pass'])) {
		echo "success";
	}
 ?>